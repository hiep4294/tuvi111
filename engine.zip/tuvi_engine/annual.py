# -*- coding: utf-8 -*-
"""Sao lưu niên theo bộ lá số tham chiếu tracuutuvi.

Bản v1.12 chỉ an 9 sao có tiền tố ``L.`` xuất hiện nhất quán trên hai
lá số tham chiếu do người dùng cung cấp:

1. Lưu Thái Tuế theo địa chi năm xem.
2. Lưu Tang Môn cách Lưu Thái Tuế 2 cung thuận.
3. Lưu Bạch Hổ cách Lưu Thái Tuế 8 cung thuận.
4. Lưu Lộc Tồn theo thiên can năm xem.
5. Lưu Kình Dương sau Lưu Lộc Tồn 1 cung.
6. Lưu Đà La trước Lưu Lộc Tồn 1 cung.
7. Lưu Thiên Mã theo tam hợp địa chi năm xem.
8. Lưu Thiên Khốc khởi Ngọ, đi nghịch theo địa chi năm xem.
9. Lưu Thiên Hư khởi Ngọ, đi thuận theo địa chi năm xem.

Không an 9 sao còn lại của vòng Thái Tuế và không an Lưu Tứ Hóa trong
profile tham chiếu này, vì chúng không được hiển thị dưới tiền tố ``L.`` trên
các lá số mẫu. Sao lưu niên luôn gắn theo địa chi cố định, không phụ thuộc
vị trí cung chức, Tiểu hạn hoặc phép bố trí giao diện.
"""
from __future__ import annotations

from typing import Dict, Iterable, List, Tuple

from tuvi_engine.legacy.AmDuong import diaChi, dichCung, thienCan, timThienMa
from tuvi_engine.presentation import star_color, star_element_name, star_nature


REFERENCE_ANNUAL_STARS: List[Tuple[str, str, int, str]] = [
    ("Thái tuế", "H", 15, "thai_tue"),
    ("Tang môn", "M", 12, "thai_tue"),
    ("Bạch hổ", "K", 12, "thai_tue"),
    ("Lộc tồn", "O", 3, "loc_ton"),
    ("Kình dương", "K", 11, "loc_ton"),
    ("Đà la", "K", 11, "loc_ton"),
    ("Thiên mã", "H", 3, "branch_auxiliary"),
    ("Thiên khốc", "T", 12, "branch_auxiliary"),
    ("Thiên hư", "T", 12, "branch_auxiliary"),
]


def year_can_chi(year: int) -> Tuple[int, int, str]:
    if not 1600 <= year <= 2600:
        raise ValueError("Năm xem lưu niên phải nằm trong khoảng 1600–2600.")
    can = ((year - 4) % 10) + 1
    chi = ((year - 4) % 12) + 1
    return can, chi, f"{thienCan[can]['tenCan']} {diaChi[chi]['tenChi']}"


def _annual_star(
    star_id: int,
    name: str,
    element: str,
    star_type: int,
    year: int,
    group: str,
) -> Dict[str, object]:
    star: Dict[str, object] = {
        "saoID": star_id,
        "saoTen": f"L.{name}",
        "saoNguHanh": element,
        "saoLoai": star_type,
        "saoDacTinh": None,
        "is_annual": True,
        "annual_year": year,
        "annual_group": group,
    }
    star["nature"] = star_nature(star)
    star["element_name"] = star_element_name(star)
    star["element_color"] = star_color(star)
    return star


def build_annual_layer(
    year: int,
    palaces: Iterable[object],
    tu_hoa_method: str,
) -> Dict[str, object]:
    """An 9 sao lưu niên tham chiếu và gắn theo địa chi cố định."""
    del tu_hoa_method  # Profile tham chiếu v1.12 không an Lưu Tứ Hóa.

    can, chi, can_chi = year_can_chi(year)
    by_branch = {int(getattr(p, "branch_id")): p for p in palaces}
    if set(by_branch) != set(range(1, 13)):
        raise ValueError("Địa bàn phải có đủ 12 địa chi trước khi an sao lưu niên.")

    for palace in by_branch.values():
        palace.annual_stars = []

    placements: List[Dict[str, object]] = []
    next_id = 2000

    def add(branch: int, name: str, element: str, star_type: int, group: str) -> None:
        nonlocal next_id
        branch = ((int(branch) - 1) % 12) + 1
        next_id += 1
        star = _annual_star(next_id, name, element, star_type, year, group)
        by_branch[branch].annual_stars.append(star)
        placements.append({
            "branch_id": branch,
            "branch": by_branch[branch].branch_name,
            **star,
        })

    # Ba sao lưu theo vòng Thái Tuế xuất hiện trên lá số tham chiếu.
    add(chi, "Thái tuế", "H", 15, "thai_tue")
    add(dichCung(chi, 2), "Tang môn", "M", 12, "thai_tue")
    add(dichCung(chi, 8), "Bạch hổ", "K", 12, "thai_tue")

    # Lưu Lộc Tồn, Lưu Kình Dương, Lưu Đà La theo thiên can năm xem.
    loc_ton = int(thienCan[can]["vitriDiaBan"])
    add(loc_ton, "Lộc tồn", "O", 3, "loc_ton")
    add(dichCung(loc_ton, 1), "Kình dương", "K", 11, "loc_ton")
    add(dichCung(loc_ton, -1), "Đà la", "K", 11, "loc_ton")

    # Lưu Thiên Mã, Lưu Thiên Khốc, Lưu Thiên Hư theo địa chi năm xem.
    add(timThienMa(chi), "Thiên mã", "H", 3, "branch_auxiliary")
    add(dichCung(7, -chi + 1), "Thiên khốc", "T", 12, "branch_auxiliary")
    add(dichCung(7, chi - 1), "Thiên hư", "T", 12, "branch_auxiliary")

    for palace in by_branch.values():
        palace.annual_stars.sort(
            key=lambda s: (str(s.get("annual_group", "")), int(s.get("saoID", 0)))
        )

    return {
        "year": year,
        "year_stem_id": can,
        "year_branch_id": chi,
        "year_can_chi": can_chi,
        "profile": "tracuutuvi_reference_9_stars",
        "star_count": len(placements),
        "scope": [
            "Lưu Thái Tuế, Lưu Tang Môn, Lưu Bạch Hổ",
            "Lưu Lộc Tồn, Lưu Kình Dương, Lưu Đà La",
            "Lưu Thiên Mã, Lưu Thiên Khốc, Lưu Thiên Hư",
        ],
        "excluded": [
            "9 sao còn lại của vòng Thái Tuế",
            "Lưu Tứ Hóa",
        ],
        "placements": placements,
    }
