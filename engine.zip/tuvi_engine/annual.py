# -*- coding: utf-8 -*-
"""Lớp sao lưu niên độc lập với lá số gốc.

Quy ước của bản v1.2:
- Người dùng chọn một năm dương lịch; năm đó được đổi trực tiếp sang Can Chi.
- Lưu Thái Tuế và 11 sao của vòng Thái Tuế an thuận từ địa chi năm xem.
- Lưu Lộc Tồn theo thiên can năm xem; Lưu Đà La trước một cung,
  Lưu Kình Dương sau một cung.
- Lưu Thiên Mã, Lưu Thiên Khốc, Lưu Thiên Hư theo địa chi năm xem.
- Lưu Tứ Hóa dùng cùng bảng Tứ Hóa đang chọn và nhập vào cung có sao gốc
  tương ứng. Sao lưu niên không thay đổi cấu trúc lá số gốc.
"""
from __future__ import annotations

from typing import Dict, Iterable, List, Tuple

from tuvi_engine.legacy.AmDuong import diaChi, dichCung, thienCan, timThienMa
from tuvi_engine.presentation import star_color, star_element_name, star_nature


ANNUAL_THAI_TUE_CYCLE: List[Tuple[str, str, int]] = [
    ("Thái tuế", "H", 15),
    ("Thiếu dương", "H", 5),
    ("Tang môn", "M", 12),
    ("Thiếu âm", "T", 5),
    ("Quan phù", "H", 12),
    ("Tử phù", "K", 12),
    ("Tuế phá", "H", 12),
    ("Long đức", "T", 5),
    ("Bạch hổ", "K", 12),
    ("Phúc đức", "O", 5),
    ("Điếu khách", "H", 12),
    ("Trực phù", "K", 16),
]

# Tứ Hóa theo đúng bảng đang dùng trong engine lá số gốc.
TU_HOA_TARGETS = {
    1: (2, 14, 4, 5),
    2: (6, 12, 1, 8),
    3: (3, 6, 57, 2),
    4: (8, 3, 6, 10),
    5: (9, 8, 62, 6),
    6: (4, 9, 12, 58),
    8: (10, 5, 58, 57),
    10: (14, 10, 8, 9),
}

ANNUAL_TRANSFORMS = [
    ("Hóa lộc", "M", 3),
    ("Hóa quyền", "T", 4),
    ("Hóa khoa", "T", 5),
    ("Hóa kỵ", "T", 13),
]


def year_can_chi(year: int) -> Tuple[int, int, str]:
    if not 1600 <= year <= 2600:
        raise ValueError("Năm xem lưu niên phải nằm trong khoảng 1600–2600.")
    can = ((year - 4) % 10) + 1
    chi = ((year - 4) % 12) + 1
    return can, chi, f"{thienCan[can]['tenCan']} {diaChi[chi]['tenChi']}"


def _annual_star(
    star_id: int,
    name: str,
    element: str,
    star_type: int,
    year: int,
    group: str,
    source_star_id: int | None = None,
    source_star_name: str | None = None,
) -> Dict[str, object]:
    star: Dict[str, object] = {
        "saoID": star_id,
        "saoTen": f"L.{name}",
        "saoNguHanh": element,
        "saoLoai": star_type,
        "saoDacTinh": None,
        "is_annual": True,
        "annual_year": year,
        "annual_group": group,
    }
    if source_star_id is not None:
        star["source_star_id"] = source_star_id
    if source_star_name:
        star["source_star_name"] = source_star_name
    star["nature"] = star_nature(star)
    star["element_name"] = star_element_name(star)
    star["element_color"] = star_color(star)
    return star


def _tu_hoa_targets(can: int, method: str) -> Tuple[int, int, int, int]:
    if can == 7:
        return (5, 4, 8, 3) if method == "toan_tap" else (5, 4, 3, 8)
    if can == 9:
        return (12, 1, 7 if method == "toan_thu" else 61, 4)
    return TU_HOA_TARGETS[can]


def build_annual_layer(
    year: int,
    palaces: Iterable[object],
    tu_hoa_method: str,
) -> Dict[str, object]:
    """Sinh sao lưu niên và gắn vào ``annual_stars`` của từng cung."""
    can, chi, can_chi = year_can_chi(year)
    by_branch = {int(getattr(p, "branch_id")): p for p in palaces}
    for palace in by_branch.values():
        palace.annual_stars = []

    placements: List[Dict[str, object]] = []
    next_id = 2000

    def add(branch: int, name: str, element: str, star_type: int, group: str,
            source_star_id: int | None = None, source_star_name: str | None = None):
        nonlocal next_id
        next_id += 1
        star = _annual_star(
            next_id, name, element, star_type, year, group,
            source_star_id=source_star_id,
            source_star_name=source_star_name,
        )
        by_branch[branch].annual_stars.append(star)
        placements.append({
            "branch_id": branch,
            "branch": by_branch[branch].branch_name,
            **star,
        })

    # Vòng Lưu Thái Tuế.
    for offset, (name, element, star_type) in enumerate(ANNUAL_THAI_TUE_CYCLE):
        add(dichCung(chi, offset), name, element, star_type, "thai_tue_cycle")

    # Lưu Lộc Tồn, Lưu Kình Dương, Lưu Đà La.
    loc_ton = int(thienCan[can]["vitriDiaBan"])
    add(loc_ton, "Lộc tồn", "O", 3, "loc_ton")
    add(dichCung(loc_ton, 1), "Kình dương", "K", 11, "loc_ton")
    add(dichCung(loc_ton, -1), "Đà la", "K", 11, "loc_ton")

    # Lưu Thiên Mã, Thiên Khốc, Thiên Hư.
    add(timThienMa(chi), "Thiên mã", "H", 3, "branch_auxiliary")
    add(dichCung(7, -chi + 1), "Thiên khốc", "T", 12, "branch_auxiliary")
    add(dichCung(7, chi - 1), "Thiên hư", "T", 12, "branch_auxiliary")

    # Lưu Tứ Hóa nhập vào vị trí của sao gốc chịu Hóa.
    star_position: Dict[int, Tuple[int, str]] = {}
    for palace in by_branch.values():
        for star in palace.stars:
            star_id = star.get("saoID")
            if isinstance(star_id, int):
                star_position[star_id] = (palace.branch_id, str(star.get("saoTen", "")))

    targets = _tu_hoa_targets(can, tu_hoa_method)
    for (transform_name, element, star_type), target_id in zip(ANNUAL_TRANSFORMS, targets):
        target = star_position.get(target_id)
        if target:
            branch, source_name = target
            add(
                branch, transform_name, element, star_type, "tu_hoa",
                source_star_id=target_id, source_star_name=source_name,
            )

    for palace in by_branch.values():
        palace.annual_stars.sort(
            key=lambda s: (str(s.get("annual_group", "")), int(s.get("saoID", 0)))
        )

    return {
        "year": year,
        "year_stem_id": can,
        "year_branch_id": chi,
        "year_can_chi": can_chi,
        "tu_hoa_method": tu_hoa_method,
        "scope": [
            "Vòng Lưu Thái Tuế 12 sao",
            "Lưu Lộc Tồn, Lưu Kình Dương, Lưu Đà La",
            "Lưu Thiên Mã, Lưu Thiên Khốc, Lưu Thiên Hư",
            "Lưu Tứ Hóa theo bảng Tứ Hóa đang chọn",
        ],
        "placements": placements,
    }
