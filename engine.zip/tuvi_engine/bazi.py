# -*- coding: utf-8 -*-
"""Bát Tự / Tứ Trụ engine for the desktop application.

Project conventions:
- Civil time is used directly in UTC+7; no longitude/solar-time correction.
- The day pillar rolls to the next day from 23:00, matching the Tử Vi module.
- Two month-pillar methods are supported: lunar-month sequence or solar terms.
- Gender affects the direction of the ten-year luck cycles, not the four pillars.

The module returns structured facts. It intentionally does not claim a definitive
Dụng thần or deterministic life prediction.
"""
from __future__ import annotations

from datetime import datetime, timedelta
import math
from typing import Dict, List, Tuple

from tuvi_engine.legacy.AmDuong import canChiNgay, nguHanhNapAm
from tuvi_engine.legacy.Lich_HND import jdFromDate
from tuvi_engine.models import BirthInput, NormalizedBirth

STEMS = ["Giáp", "Ất", "Bính", "Đinh", "Mậu", "Kỷ", "Canh", "Tân", "Nhâm", "Quý"]
BRANCHES = ["Tý", "Sửu", "Dần", "Mão", "Thìn", "Tỵ", "Ngọ", "Mùi", "Thân", "Dậu", "Tuất", "Hợi"]
ELEMENTS = ["Mộc", "Hỏa", "Thổ", "Kim", "Thủy"]
STEM_ELEMENT = [0, 0, 1, 1, 2, 2, 3, 3, 4, 4]
BRANCH_ELEMENT = [4, 2, 0, 0, 2, 1, 1, 2, 3, 3, 2, 4]
YIN_YANG = ["Dương", "Âm"]

# Hidden stems ordered from principal qi to secondary/residual qi.
HIDDEN_STEMS = {
    0: [9],          # Tý: Quý
    1: [5, 9, 7],    # Sửu: Kỷ Quý Tân
    2: [0, 2, 4],    # Dần: Giáp Bính Mậu
    3: [1],          # Mão: Ất
    4: [4, 1, 9],    # Thìn: Mậu Ất Quý
    5: [2, 4, 6],    # Tỵ: Bính Mậu Canh
    6: [3, 5],       # Ngọ: Đinh Kỷ
    7: [5, 3, 1],    # Mùi: Kỷ Đinh Ất
    8: [6, 8, 4],    # Thân: Canh Nhâm Mậu
    9: [7],          # Dậu: Tân
    10: [4, 7, 3],   # Tuất: Mậu Tân Đinh
    11: [8, 0],      # Hợi: Nhâm Giáp
}
HIDDEN_WEIGHTS = {1: [1.0], 2: [0.7, 0.3], 3: [0.6, 0.25, 0.15]}

# 12 Jie boundaries defining Bazi months, starting with Li Chun (Dần month).
MONTH_BOUNDARY_DEGREES = [315, 345, 15, 45, 75, 105, 135, 165, 195, 225, 255, 285]
MONTH_JIE_NAMES = [
    "Lập Xuân", "Kinh Trập", "Thanh Minh", "Lập Hạ",
    "Mang Chủng", "Tiểu Thử", "Lập Thu", "Bạch Lộ",
    "Hàn Lộ", "Lập Đông", "Đại Tuyết", "Tiểu Hàn",
]

TEN_GOD_LABELS = {
    "peer_same": "Tỷ Kiên",
    "peer_other": "Kiếp Tài",
    "output_same": "Thực Thần",
    "output_other": "Thương Quan",
    "wealth_same": "Thiên Tài",
    "wealth_other": "Chính Tài",
    "officer_same": "Thất Sát",
    "officer_other": "Chính Quan",
    "resource_same": "Thiên Ấn",
    "resource_other": "Chính Ấn",
}


def _julian_day_utc(local_dt: datetime, timezone: float = 7.0) -> float:
    hour_utc = local_dt.hour + local_dt.minute / 60.0 + local_dt.second / 3600.0 - timezone
    return jdFromDate(local_dt.day, local_dt.month, local_dt.year) - 0.5 + hour_utc / 24.0


def solar_longitude_deg(local_dt: datetime, timezone: float = 7.0) -> float:
    """Apparent geocentric solar longitude in degrees.

    Uses the same Meeus approximation as the lunar-calendar module, but keeps
    the fractional longitude instead of reducing it to a 30-degree sector.
    """
    jdn = _julian_day_utc(local_dt, timezone)
    t = (jdn - 2451545.0) / 36525.0
    t2 = t * t
    dr = math.pi / 180.0
    mean_anomaly = 357.52910 + 35999.05030 * t - 0.0001559 * t2 - 0.00000048 * t * t2
    mean_longitude = 280.46645 + 36000.76983 * t + 0.0003032 * t2
    correction = (1.914600 - 0.004817 * t - 0.000014 * t2) * math.sin(dr * mean_anomaly)
    correction += (0.019993 - 0.000101 * t) * math.sin(dr * 2 * mean_anomaly)
    correction += 0.000290 * math.sin(dr * 3 * mean_anomaly)
    omega = 125.04 - 1934.136 * t
    apparent = mean_longitude + correction - 0.00569 - 0.00478 * math.sin(omega * dr)
    return apparent % 360.0


def month_order_from_longitude(longitude: float) -> int:
    """0=Dần month at Li Chun, ..., 11=Sửu month at Xiao Han."""
    return int(((longitude - 315.0) % 360.0) // 30.0)


def _find_lichun(year: int) -> datetime:
    """Find local UTC+7 Li Chun by bisection around Jan-Feb."""
    lo = datetime(year, 1, 20, 0, 0)
    hi = datetime(year, 2, 20, 0, 0)
    # Before Li Chun the Bazi month order is 11, after it is 0.
    for _ in range(60):
        mid = lo + (hi - lo) / 2
        if month_order_from_longitude(solar_longitude_deg(mid)) == 11:
            lo = mid
        else:
            hi = mid
    return hi


def _find_month_boundary(birth: datetime, forward: bool) -> datetime:
    """Find the nearest Jie boundary in the selected direction."""
    start_order = month_order_from_longitude(solar_longitude_deg(birth))
    step = timedelta(hours=6)
    inside = birth
    outside = birth
    for _ in range(200):  # 50 days is safely beyond one Bazi month.
        outside = outside + step if forward else outside - step
        if month_order_from_longitude(solar_longitude_deg(outside)) != start_order:
            break
        inside = outside
    else:
        raise RuntimeError("Không tìm được mốc tiết khí gần ngày sinh.")

    if forward:
        lo, hi = inside, outside
        for _ in range(55):
            mid = lo + (hi - lo) / 2
            if month_order_from_longitude(solar_longitude_deg(mid)) == start_order:
                lo = mid
            else:
                hi = mid
        return hi

    lo, hi = outside, inside
    for _ in range(55):
        mid = lo + (hi - lo) / 2
        if month_order_from_longitude(solar_longitude_deg(mid)) == start_order:
            hi = mid
        else:
            lo = mid
    return hi


def ten_god(day_stem: int, target_stem: int) -> str:
    dm_element = STEM_ELEMENT[day_stem]
    target_element = STEM_ELEMENT[target_stem]
    same_polarity = (day_stem % 2) == (target_stem % 2)

    if target_element == dm_element:
        key = "peer_same" if same_polarity else "peer_other"
    elif target_element == (dm_element + 1) % 5:  # day master produces target
        key = "output_same" if same_polarity else "output_other"
    elif target_element == (dm_element + 2) % 5:  # day master controls target
        key = "wealth_same" if same_polarity else "wealth_other"
    elif target_element == (dm_element + 3) % 5:  # target controls day master
        key = "officer_same" if same_polarity else "officer_other"
    else:  # target produces day master
        key = "resource_same" if same_polarity else "resource_other"
    return TEN_GOD_LABELS[key]


def _pillar(stem: int, branch: int, day_stem: int, label: str) -> Dict[str, object]:
    hidden = []
    for hidden_stem in HIDDEN_STEMS[branch]:
        hidden.append({
            "stem_id": hidden_stem,
            "stem": STEMS[hidden_stem],
            "element": ELEMENTS[STEM_ELEMENT[hidden_stem]],
            "yin_yang": YIN_YANG[hidden_stem % 2],
            "ten_god": "Nhật chủ" if hidden_stem == day_stem else ten_god(day_stem, hidden_stem),
        })
    return {
        "label": label,
        "stem_id": stem,
        "stem": STEMS[stem],
        "branch_id": branch,
        "branch": BRANCHES[branch],
        "text": f"{STEMS[stem]} {BRANCHES[branch]}",
        "stem_element": ELEMENTS[STEM_ELEMENT[stem]],
        "branch_element": ELEMENTS[BRANCH_ELEMENT[branch]],
        "yin_yang": YIN_YANG[stem % 2],
        "ten_god": "Nhật chủ" if label == "Ngày" else ten_god(day_stem, stem),
        "hidden_stems": hidden,
        "nap_am": nguHanhNapAm(branch + 1, stem + 1, True),
    }


def _element_balance(pillars: List[Tuple[int, int]]) -> Dict[str, object]:
    scores = [0.0] * 5
    details: List[Dict[str, object]] = []
    for pillar_index, (stem, branch) in enumerate(pillars):
        scores[STEM_ELEMENT[stem]] += 1.0
        details.append({"source": "thiên can", "pillar": pillar_index, "element": ELEMENTS[STEM_ELEMENT[stem]], "weight": 1.0})
        hidden = HIDDEN_STEMS[branch]
        weights = HIDDEN_WEIGHTS[len(hidden)]
        season_factor = 1.5 if pillar_index == 1 else 1.0  # month branch carries seasonal authority
        for hidden_stem, weight in zip(hidden, weights):
            value = weight * season_factor
            scores[STEM_ELEMENT[hidden_stem]] += value
            details.append({"source": "tàng can", "pillar": pillar_index, "element": ELEMENTS[STEM_ELEMENT[hidden_stem]], "weight": round(value, 3)})
    total = sum(scores) or 1.0
    percentages = {ELEMENTS[i]: round(scores[i] / total * 100.0, 1) for i in range(5)}
    raw = {ELEMENTS[i]: round(scores[i], 3) for i in range(5)}
    ordered = sorted(percentages.items(), key=lambda item: (-item[1], item[0]))
    return {
        "raw": raw,
        "percentages": percentages,
        "dominant": ordered[0][0],
        "weakest": ordered[-1][0],
        "details": details,
    }


def _day_master_assessment(day_stem: int, balance: Dict[str, object]) -> Dict[str, object]:
    element = STEM_ELEMENT[day_stem]
    percentages = balance["percentages"]
    peer = percentages[ELEMENTS[element]]
    resource = percentages[ELEMENTS[(element - 1) % 5]]
    support = peer + resource
    if support >= 55:
        level = "Khá vượng"
        balancing = [ELEMENTS[(element + 1) % 5], ELEMENTS[(element + 2) % 5], ELEMENTS[(element + 3) % 5]]
    elif support <= 40:
        level = "Khá nhược"
        balancing = [ELEMENTS[(element - 1) % 5], ELEMENTS[element]]
    else:
        level = "Tương đối cân bằng"
        balancing = [ELEMENTS[(element + 1) % 5], ELEMENTS[(element - 1) % 5]]
    return {
        "stem": STEMS[day_stem],
        "element": ELEMENTS[element],
        "yin_yang": YIN_YANG[day_stem % 2],
        "support_ratio_percent": round(support, 1),
        "preliminary_strength": level,
        "balancing_elements_preliminary": balancing,
        "warning": "Đây là chỉ báo cân bằng sơ bộ, không thay thế phép định Dụng thần chuyên sâu.",
    }


def _ten_god_distribution(day_stem: int, pillars: List[Tuple[int, int]]) -> Dict[str, float]:
    result: Dict[str, float] = {}
    for pillar_index, (stem, branch) in enumerate(pillars):
        if pillar_index != 2:  # do not count the visible day master as a Ten God
            name = ten_god(day_stem, stem)
            result[name] = result.get(name, 0.0) + 1.0
        hidden = HIDDEN_STEMS[branch]
        weights = HIDDEN_WEIGHTS[len(hidden)]
        for hidden_stem, weight in zip(hidden, weights):
            name = "Nhật chủ" if hidden_stem == day_stem else ten_god(day_stem, hidden_stem)
            result[name] = result.get(name, 0.0) + weight
    return {key: round(value, 2) for key, value in sorted(result.items())}


def _luck_cycles(
    birth_dt: datetime,
    gender: int,
    year_stem: int,
    month_stem: int,
    month_branch: int,
    day_stem: int,
) -> Dict[str, object]:
    yang_year = year_stem % 2 == 0
    forward = (gender == 1 and yang_year) or (gender == -1 and not yang_year)
    boundary = _find_month_boundary(birth_dt, forward)
    interval_days = abs((boundary - birth_dt).total_seconds()) / 86400.0
    start_age = interval_days / 3.0
    start_years = int(start_age)
    start_months = int(round((start_age - start_years) * 12))
    if start_months == 12:
        start_years += 1
        start_months = 0

    cycles = []
    direction = 1 if forward else -1
    for index in range(1, 9):
        stem = (month_stem + direction * index) % 10
        branch = (month_branch + direction * index) % 12
        pillar = _pillar(stem, branch, day_stem, f"Đại vận {index}")
        pillar.update({
            "index": index,
            "start_age": round(start_age + (index - 1) * 10, 2),
            "end_age": round(start_age + index * 10, 2),
        })
        cycles.append(pillar)
    return {
        "direction": "Thuận" if forward else "Nghịch",
        "boundary_time": boundary.isoformat(timespec="minutes"),
        "start_age_decimal": round(start_age, 2),
        "start_age_text": f"Khoảng {start_years} năm {start_months} tháng",
        "cycles": cycles,
        "method": "Khoảng cách đến tiết khí kế/ trước chia 3 ngày = 1 năm.",
    }


def generate_bazi(data: BirthInput, normalized: NormalizedBirth) -> Dict[str, object]:
    birth_dt = normalized.input_solar_datetime
    longitude = solar_longitude_deg(birth_dt)
    lichun = _find_lichun(birth_dt.year)

    method = getattr(data, "bazi_month_method", "lunar") or "lunar"
    if method not in {"lunar", "jieqi"}:
        raise ValueError("Phương pháp xác định tháng Bát Tự phải là 'lunar' hoặc 'jieqi'.")

    if method == "lunar":
        # User-selected convention: use the effective Vietnamese lunar year/month.
        # Month 1 starts at Dần, month 2 at Mão, ..., month 12 at Sửu.
        bazi_year = normalized.chart_lunar_year
        year_stem = (bazi_year - 4) % 10
        year_branch = (bazi_year - 4) % 12
        month_order = normalized.chart_lunar_month - 1
        month_branch = (2 + month_order) % 12
        tiger_month_stem = (year_stem * 2 + 2) % 10
        month_stem = (tiger_month_stem + month_order) % 10
        month_method_name = "Theo tháng âm"
        month_basis_label = (
            f"Tháng âm {normalized.chart_lunar_month} → {BRANCHES[month_branch]} "
            f"(tháng 1 khởi Dần)"
        )
        year_boundary_text = "Theo năm âm lịch hiệu dụng"
        month_boundary_text = "Tháng âm: 1=Dần, 2=Mão, 3=Thìn, ..., 12=Sửu"
        month_jie = "Không áp dụng trong chế độ tháng âm"
    else:
        # Classical Four Pillars convention: year changes at Li Chun and month at 12 Jie.
        bazi_year = birth_dt.year if birth_dt >= lichun else birth_dt.year - 1
        year_stem = (bazi_year - 4) % 10
        year_branch = (bazi_year - 4) % 12
        month_order = month_order_from_longitude(longitude)
        month_branch = (2 + month_order) % 12
        tiger_month_stem = (year_stem * 2 + 2) % 10
        month_stem = (tiger_month_stem + month_order) % 10
        month_method_name = "Theo tiết khí"
        month_basis_label = MONTH_JIE_NAMES[month_order]
        year_boundary_text = "Lập Xuân"
        month_boundary_text = "12 tiết khí (Jie)"
        month_jie = MONTH_JIE_NAMES[month_order]

    can_day_1, chi_day_1 = canChiNgay(
        normalized.effective_solar_date.day,
        normalized.effective_solar_date.month,
        normalized.effective_solar_date.year,
        True,
        7,
    )
    day_stem = can_day_1 - 1
    day_branch = chi_day_1 - 1
    hour_branch = normalized.hour_branch - 1
    zi_hour_stem = (day_stem % 5) * 2
    hour_stem = (zi_hour_stem + hour_branch) % 10

    raw_pillars = [
        (year_stem, year_branch),
        (month_stem, month_branch),
        (day_stem, day_branch),
        (hour_stem, hour_branch),
    ]
    labels = ["Năm", "Tháng", "Ngày", "Giờ"]
    pillars = [_pillar(stem, branch, day_stem, label) for (stem, branch), label in zip(raw_pillars, labels)]
    balance = _element_balance(raw_pillars)
    day_master = _day_master_assessment(day_stem, balance)
    luck = _luck_cycles(birth_dt, data.gender, year_stem, month_stem, month_branch, day_stem)

    return {
        "engine_version": "bazi-jieqi-default-1.3.0",
        "conventions": {
            "timezone": "UTC+7",
            "time_correction": "Không hiệu chỉnh kinh độ hoặc giờ mặt trời",
            "day_boundary": "23:00 tính sang ngày kế tiếp",
            "year_boundary": year_boundary_text,
            "month_boundary": month_boundary_text,
            "luck_direction": "Theo giới tính và âm dương thiên can năm",
        },
        "birth_solar_datetime": birth_dt.isoformat(timespec="minutes"),
        "effective_day_date": normalized.effective_solar_date.isoformat(),
        "effective_lunar_date": (
            f"{normalized.chart_lunar_day}/{normalized.chart_lunar_month}/{normalized.chart_lunar_year}"
        ),
        "solar_longitude_degrees": round(longitude, 5),
        "lichun_time": lichun.isoformat(timespec="minutes"),
        "bazi_year": bazi_year,
        "month_method": method,
        "month_method_name": month_method_name,
        "month_basis_label": month_basis_label,
        "month_jie": month_jie,
        "pillars": pillars,
        "day_master": day_master,
        "element_balance": balance,
        "ten_god_distribution": _ten_god_distribution(day_stem, raw_pillars),
        "luck_cycles": luck,
    }

