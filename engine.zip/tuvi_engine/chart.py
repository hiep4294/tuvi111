# -*- coding: utf-8 -*-
from typing import Dict, List

from tuvi_engine.legacy.AmDuong import (
    canChiNgay,
    diaChi,
    ngayThangNamCanChi,
    nguHanh,
    nguHanhNapAm,
    sinhKhac,
    thienCan,
    timCuc,
)
from tuvi_engine.legacy.App import lapDiaBan
from tuvi_engine.legacy.DiaBan import diaBan
from tuvi_engine.legacy.Lich_HND import jdFromDate
from tuvi_engine.models import BirthInput, ChartData, PalaceData
from tuvi_engine.bazi import generate_bazi
from tuvi_engine.annual import build_annual_layer
from tuvi_engine.integration import build_combined_analysis
from tuvi_engine.normalizer import normalize_birth
from tuvi_engine.relations import build_relations
from tuvi_engine.presentation import star_color, star_element_name, star_nature
from tuvi_engine.prompts import prompt_profile_metadata

ENGINE_VERSION = "web-tuvi-bazi-1.12.0+fixed-branch-frame+reference-annual-9-stars+gemini"

_BRANCH_ELEMENTS = {
    1: "Thủy", 2: "Thổ", 3: "Mộc", 4: "Mộc",
    5: "Thổ", 6: "Hỏa", 7: "Hỏa", 8: "Thổ",
    9: "Kim", 10: "Kim", 11: "Thổ", 12: "Thủy",
}

_PALACE_NAMES_CLOCKWISE = [
    "Mệnh", "Phụ mẫu", "Phúc đức", "Điền trạch", "Quan lộc", "Nô bộc",
    "Thiên di", "Tật Ách", "Tài Bạch", "Tử tức", "Phu thê", "Huynh đệ",
]
_FIXED_BRANCH_CLOCKWISE = [3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 1, 2]
_BRANCH_ID_BY_NAME = {diaChi[i]["tenChi"]: i for i in range(1, 13)}


def _normalize_branch(value: int) -> int:
    return ((int(value) - 1) % 12) + 1


def reference_branch(legacy_branch: int, hour_branch: int) -> int:
    """Giữ nguyên địa chi do công thức an Mệnh/an sao gốc xác định.

    Khung địa chi trên giao diện là cố định: Dần, Mão, Thìn, Tỵ, Ngọ, Mùi,
    Thân, Dậu, Tuất, Hợi, Tý, Sửu. Không xoay hay phản chiếu địa bàn theo
    giờ sinh; ``hour_branch`` chỉ được giữ trong chữ ký hàm để tương thích.
    """
    del hour_branch
    return _normalize_branch(int(legacy_branch))


def build_chart_id(
    gender: int,
    lunar_year: int,
    lunar_month: int,
    lunar_day: int,
    hour_branch: int,
) -> int:
    gender_index = 0 if gender == 1 else 1
    year_cycle = (lunar_year - 1984) % 60  # 1984 = Giáp Tý
    return (
        ((((gender_index * 60 + year_cycle) * 12 + (lunar_month - 1))
          * 30 + (lunar_day - 1)) * 12 + (hour_branch - 1)) + 1
    )


def generate_chart(data: BirthInput) -> ChartData:
    normalized = normalize_birth(data)
    n = normalized

    # Lõi an sao giữ tọa độ legacy đã được kiểm tra ổn định. Sau khi an xong mới
    # chuyển toàn bộ địa bàn sang tọa độ của lá số tham chiếu trong một bước.
    board = lapDiaBan(
        diaBan,
        n.chart_lunar_day,
        n.chart_lunar_month,
        n.chart_lunar_year,
        n.hour_branch,
        data.gender,
        False,
        7,
        data.tu_hoa_method,
        data.placement_profile,
    )

    legacy_palaces = _extract_legacy_palaces(board)
    annual = build_annual_layer(data.annual_year, legacy_palaces, data.tu_hoa_method)
    display_menh_branch = reference_branch(board.cungMenh, n.hour_branch)
    palaces = _transform_palaces(
        legacy_palaces,
        n.hour_branch,
        display_menh_branch,
    )
    _validate_fixed_palace_assignment(palaces, display_menh_branch)
    _transform_annual_metadata(annual, n.hour_branch)

    relations = build_relations([p.to_dict() for p in palaces])
    heaven = _build_heaven(data, n, board, palaces)
    heaven["annual_year"] = annual["year"]
    heaven["annual_year_can_chi"] = annual["year_can_chi"]
    chart_id = build_chart_id(
        data.gender,
        n.chart_lunar_year,
        n.chart_lunar_month,
        n.chart_lunar_day,
        n.hour_branch,
    )

    bazi = generate_bazi(data, n)
    chart = ChartData(
        chart_id=chart_id,
        engine_version=ENGINE_VERSION,
        input=data,
        normalized=n,
        heaven=heaven,
        palaces=palaces,
        relations=relations,
        bazi=bazi,
        combined_analysis={},
        annual=annual,
    )
    chart.combined_analysis = build_combined_analysis(chart)
    chart.combined_analysis["prompt_profile"] = prompt_profile_metadata()
    return chart


def _extract_legacy_palaces(board) -> List[PalaceData]:
    result: List[PalaceData] = []
    for item in board.thapNhiCung[1:]:
        stars = [dict(s) for s in item.cungSao]
        for star in stars:
            star["nature"] = star_nature(star)
            star["element_name"] = star_element_name(star)
            star["element_color"] = star_color(star)
        stars.sort(
            key=lambda s: (
                0 if s.get("saoLoai") == 1 else 1,
                s.get("saoLoai", 99),
                s.get("saoID", 999),
            )
        )
        result.append(
            PalaceData(
                branch_id=item.cungSo,
                branch_name=item.cungTen,
                element=item.hanhCung,
                palace_name=getattr(item, "cungChu", ""),
                is_body=bool(getattr(item, "cungThan", False)),
                major_limit=int(getattr(item, "cungDaiHan", 0)),
                minor_limit=str(getattr(item, "cungTieuHan", "")),
                has_tuan=bool(getattr(item, "tuanTrung", False)),
                has_triet=bool(getattr(item, "trietLo", False)),
                stars=stars,
                annual_stars=[],
            )
        )
    return result


def _palace_name_at_branch(branch_id: int, menh_branch: int) -> str:
    """Gán 12 cung chức trên khung địa chi cố định.

    Thứ tự địa chi cố định dùng để an cung chức là:
    Dần → Mão → Thìn → Tỵ → Ngọ → Mùi → Thân → Dậu → Tuất → Hợi → Tý → Sửu.
    Cung Mệnh được đặt tại ``menh_branch`` do công thức tháng âm và giờ sinh
    xác định; Phụ Mẫu, Phúc Đức... đi tiếp theo thứ tự trên. Tiểu hạn không
    tham gia phép gán này.
    """
    menh_index = _FIXED_BRANCH_CLOCKWISE.index(_normalize_branch(menh_branch))
    branch_index = _FIXED_BRANCH_CLOCKWISE.index(_normalize_branch(branch_id))
    offset = (branch_index - menh_index) % 12
    return _PALACE_NAMES_CLOCKWISE[offset]


def _validate_fixed_palace_assignment(palaces: List[PalaceData], menh_branch: int) -> None:
    """Bảo đảm cung chức chỉ phụ thuộc khung địa chi và vị trí Mệnh."""
    by_branch = {int(p.branch_id): p for p in palaces}
    menh_index = _FIXED_BRANCH_CLOCKWISE.index(_normalize_branch(menh_branch))
    for offset, expected_name in enumerate(_PALACE_NAMES_CLOCKWISE):
        branch_id = _FIXED_BRANCH_CLOCKWISE[(menh_index + offset) % 12]
        palace = by_branch.get(branch_id)
        if palace is None:
            raise ValueError(f"Thiếu địa chi cố định {diaChi[branch_id]['tenChi']}")
        if palace.palace_name.casefold() != expected_name.casefold():
            raise ValueError(
                f"Sai cung chức tại {diaChi[branch_id]['tenChi']}: "
                f"cần {expected_name}, nhận {palace.palace_name}"
            )
    menh_palace = by_branch[_normalize_branch(menh_branch)]
    if menh_palace.palace_name.casefold() != "mệnh":
        raise ValueError("Cung Mệnh không nằm trên địa chi Mệnh đã tính")


def _transform_minor_limit(minor_limit: str, hour_branch: int) -> str:
    """Đổi nhãn Tiểu hạn sang cùng hệ tọa độ hiển thị.

    Giữ nguyên địa chi Tiểu hạn do engine gốc tính. Tiểu hạn là lớp hạn độc lập,
    không được dùng để xác định vị trí cung Mệnh hoặc tên 12 cung chức.
    """
    legacy_id = _BRANCH_ID_BY_NAME.get(str(minor_limit))
    if not legacy_id:
        return str(minor_limit or "")
    display_id = reference_branch(legacy_id, hour_branch)
    return diaChi[display_id]["tenChi"]


def _transform_palaces(
    palaces: List[PalaceData],
    hour_branch: int,
    menh_branch: int,
) -> List[PalaceData]:
    transformed: List[PalaceData] = []
    for palace in palaces:
        new_branch = reference_branch(palace.branch_id, hour_branch)
        transformed.append(
            PalaceData(
                branch_id=new_branch,
                branch_name=diaChi[new_branch]["tenChi"],
                element=_BRANCH_ELEMENTS[new_branch],
                palace_name=_palace_name_at_branch(new_branch, menh_branch),
                is_body=palace.is_body,
                major_limit=palace.major_limit,
                minor_limit=_transform_minor_limit(palace.minor_limit, hour_branch),
                has_tuan=palace.has_tuan,
                has_triet=palace.has_triet,
                stars=palace.stars,
                annual_stars=palace.annual_stars,
            )
        )
    transformed.sort(key=lambda p: p.branch_id)
    return transformed


def _transform_annual_metadata(annual: Dict[str, object], hour_branch: int) -> None:
    placements = annual.get("placements") or []
    for item in placements:
        old_branch = int(item.get("branch_id", 1))
        new_branch = reference_branch(old_branch, hour_branch)
        item["legacy_branch_id"] = old_branch
        item["branch_id"] = new_branch
        item["branch"] = diaChi[new_branch]["tenChi"]
    annual["display_coordinate"] = "standard_fixed_branch_frame"


def _build_heaven(data, n, board, palaces: List[PalaceData]) -> Dict[str, object]:
    can_thang, can_nam, chi_nam = ngayThangNamCanChi(
        n.chart_lunar_day, n.chart_lunar_month, n.chart_lunar_year, False, 7
    )
    can_ngay, chi_ngay = canChiNgay(
        n.effective_solar_date.day,
        n.effective_solar_date.month,
        n.effective_solar_date.year,
        True,
        7,
    )
    can_gio = (
        (jdFromDate(
            n.effective_solar_date.day,
            n.effective_solar_date.month,
            n.effective_solar_date.year,
        ) - 1) * 2 % 10 + n.hour_branch
    ) % 10
    if can_gio == 0:
        can_gio = 10

    # Cục phải tính trong tọa độ an sao gốc; đổi tọa độ chỉ dùng cho hiển thị.
    cuc_code = timCuc(board.cungMenh, can_nam)
    cuc = nguHanh(cuc_code)
    menh_code = nguHanhNapAm(chi_nam, can_nam)
    menh_id = nguHanh(menh_code)["id"]
    relation = sinhKhac(menh_id, cuc["id"])
    relation_text = {
        1: "Bản Mệnh sinh Cục",
        -1: "Bản Mệnh khắc Cục",
        -1j: "Cục khắc Bản Mệnh",
        1j: "Cục sinh Bản Mệnh",
        0: "Cục hòa Bản Mệnh",
    }.get(relation, "Quan hệ Mệnh–Cục chưa xác định")

    display_menh = reference_branch(board.cungMenh, n.hour_branch)
    display_than = reference_branch(board.cungThan, n.hour_branch)

    # Bộ lá số tham chiếu xác định thuận/nghịch lý theo âm dương nơi Mệnh đóng
    # và giới tính, không dùng âm dương Can năm.
    menh_yin_yang = 1 if display_menh % 2 == 1 else -1
    am_duong_menh = (
        "Âm dương thuận lý"
        if menh_yin_yang * data.gender == 1
        else "Âm dương nghịch lý"
    )

    body_palace = next((p.palace_name for p in palaces if p.is_body), "")
    major_limit_forward = thienCan[can_nam]["amDuong"] * data.gender == 1
    major_limit_direction = "Thuận" if major_limit_forward else "Nghịch"
    month_branch_id = ((n.chart_lunar_month + 1) % 12) + 1

    return {
        "name": data.name or "Không ghi tên",
        "gender": "Nam" if data.gender == 1 else "Nữ",
        "input_time": n.input_solar_datetime.strftime("%d/%m/%Y %H:%M"),
        "solar_date": n.effective_solar_date.strftime("%d/%m/%Y"),
        "lunar_date": f"{n.lunar_day}/{n.lunar_month}/{n.lunar_year}"
        + (" nhuận" if n.lunar_leap else ""),
        "chart_lunar_date": (
            f"{n.chart_lunar_day}/{n.chart_lunar_month}/{n.chart_lunar_year}"
        ),
        "year_can_chi": (
            f"{thienCan[can_nam]['tenCan']} {diaChi[chi_nam]['tenChi']}"
        ),
        "month_can_chi": (
            f"{thienCan[can_thang]['tenCan']} "
            f"{diaChi[month_branch_id]['tenChi']}"
        ),
        "day_can_chi": (
            f"{thienCan[can_ngay]['tenCan']} {diaChi[chi_ngay]['tenChi']}"
        ),
        "hour_can_chi": (
            f"{thienCan[can_gio]['tenCan']} {diaChi[n.hour_branch]['tenChi']}"
        ),
        "ban_menh": nguHanhNapAm(chi_nam, can_nam, True),
        "cuc": cuc["tenCuc"],
        "menh_cuc_relation": relation_text,
        "am_duong_year": "Dương" if thienCan[can_nam]["amDuong"] == 1 else "Âm",
        "am_duong_menh": am_duong_menh,
        "menh_chu": diaChi[chi_nam]["menhChu"],
        "than_chu": diaChi[chi_nam]["thanChu"],
        "menh_branch": display_menh,
        "than_branch": display_than,
        "legacy_menh_branch": board.cungMenh,
        "legacy_than_branch": board.cungThan,
        "than_cu": body_palace,
        "major_limit_direction": major_limit_direction,
        "rolled_at_23": n.rolled_at_23,
        "time_rule": "Dùng trực tiếp giờ nhập; không hiệu chỉnh giờ mặt trời. Âm lịch tính theo múi giờ UTC+7.",
        "tu_hoa_method": data.tu_hoa_method,
        "placement_profile": data.placement_profile,
        "palace_direction": "Khung địa chi cố định: Dần → Mão → Thìn → Tỵ → Ngọ → Mùi → Thân → Dậu → Tuất → Hợi → Tý → Sửu; từ Mệnh đi tiếp Phụ Mẫu, Phúc Đức...",
        "coordinate_rule": "Không xoay địa bàn theo giờ sinh. Cung Mệnh lấy trực tiếp từ công thức an Mệnh gốc; 11 cung chức an tiếp theo khung địa chi cố định. Tiểu hạn chỉ là lớp hạn riêng.",
        "placement_profile_label": {
            "tracuutuvi_reference": "Theo hai lá số tham chiếu TraCuuTuVi",
            "legacy_v1": "Quy tắc legacy v1.0",
        }.get(data.placement_profile, data.placement_profile),
        "rule_profile": {
            "nam_phai_viet": "Nam phái Việt (cấu hình dự án): Canh Đồng Khoa/Âm Kỵ; Nhâm Tả Phụ Khoa",
            "toan_thu": "Tử Vi Đẩu Số Toàn Thư: Canh Đồng Khoa/Âm Kỵ; Nhâm Thiên Phủ Khoa",
            "toan_tap": "Tử Vi Đẩu Số Toàn Tập: Canh Thái Âm Khoa/Thiên Đồng Kỵ; Nhâm Tả Phụ Khoa",
        }.get(data.tu_hoa_method, data.tu_hoa_method),
        "star_placement_audit": {
            "status": "standard_formula_regression_checked",
            "verified_scope": [
                "Công thức an Mệnh theo tháng âm và giờ địa chi",
                "Khung 12 địa chi cố định không xoay",
                "12 cung chức an từ Mệnh theo Dần-Mão-Thìn-...-Sửu",
                "Cung Thân giữ đúng địa chi engine gốc",
                "Tiểu hạn độc lập với cung chức",
            ],
            "pending_rules": [
                "Chưa đủ mẫu độc lập để chứng minh toàn bộ 518.400 tổ hợp",
                "Một số bảng miếu-vượng phụ tinh vẫn có dị bản",
            ],
        },
    }
