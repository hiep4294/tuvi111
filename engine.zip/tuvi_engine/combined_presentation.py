# -*- coding: utf-8 -*-
"""Human-readable presentation for the Tử Vi + Bát Tự bridge.

This module deliberately avoids JSON rendering. It converts the structured
facts produced by the two engines into stable labels, rows, and text blocks
that can be used by the desktop UI and HTML exporter.
"""
from __future__ import annotations

from typing import Dict, Iterable, List, Tuple


LABELS = {
    "day_master": "Nhật chủ",
    "month_pillar": "Trụ Tháng",
    "year_pillar": "Trụ Năm",
    "hour_pillar": "Trụ Giờ",
    "element_balance": "Phân bố Ngũ Hành",
    "peer_resource": "Tỷ Kiếp và Ấn",
    "officer": "Quan và Sát",
    "resource": "Ấn tinh",
    "output": "Thực Thương",
    "luck_cycles": "Đại vận",
    "wealth": "Tài tinh",
    "wealth_element": "Hành Tài tinh",
    "day_branch_spouse_palace": "Cung phối ngẫu Bát Tự",
    "spouse_ten_gods": "Tinh phối ngẫu",
    "spouse_rule": "Quy tắc phối ngẫu",
    "dominant_element": "Ngũ Hành trội",
    "weakest_element": "Ngũ Hành yếu",
    "warning": "Lưu ý",
    "peer": "Tỷ Kiếp",
}

FOCUS_BY_TOPIC = {
    "Bản thân và khí chất": (
        "Đối chiếu cung Mệnh với Nhật chủ, tháng lệnh và tỷ lệ Ngũ Hành. "
        "Tử Vi mô tả cấu trúc cung; Bát Tự mô tả khí thế của Nhật chủ."
    ),
    "Sự nghiệp và năng lực làm việc": (
        "Đối chiếu Quan Lộc–Mệnh với Quan/Sát, Ấn và Thực Thương. "
        "Đại vận chỉ dùng để xác định giai đoạn phát huy, không thay thế lá số gốc."
    ),
    "Tài chính và khả năng tạo nguồn lực": (
        "Đối chiếu Tài Bạch–Điền Trạch với Tài tinh và Thực Thương. "
        "Một hệ mạnh, một hệ yếu được hiểu là có năng lực nhưng điều kiện phát huy không đồng đều."
    ),
    "Hôn nhân và quan hệ gắn bó": (
        "Đối chiếu cung Phu Thê với chi ngày và tinh phối ngẫu. "
        "Không kết luận tuyệt đối chỉ từ một sao hoặc một Thập Thần."
    ),
    "Gia đình, nền tảng và phúc khí": (
        "Đối chiếu Phụ Mẫu–Phúc Đức–Điền Trạch với trụ Năm, trụ Tháng và Ấn tinh."
    ),
    "Sức khỏe và cân bằng thể chất": (
        "Đối chiếu Tật Ách với phân bố Ngũ Hành; chỉ dùng như dữ kiện huyền học, không chẩn đoán bệnh."
    ),
    "Môi trường xã hội và dịch chuyển": (
        "Đối chiếu Thiên Di–Nô Bộc với Tỷ Kiếp, Thực Thương và trụ Giờ."
    ),
}


def _join(items: Iterable[object], empty: str = "—") -> str:
    values = [str(item) for item in items if item not in (None, "")]
    return ", ".join(values) if values else empty



def relation_star_labels(item: Dict[str, object], group: str) -> List[str]:
    """Return labels like 'Hoa Cái (Kim)' while preserving old relation payloads."""
    detail_key = {
        "major": "major_star_details",
        "good": "good_star_details",
        "bad": "bad_star_details",
        "transformations": "transformation_details",
    }[group]
    legacy_key = {
        "major": "major_stars",
        "good": "good_stars",
        "bad": "bad_stars",
        "transformations": "transformations",
    }[group]
    details = item.get(detail_key, []) or []
    if isinstance(details, list) and details:
        labels = []
        for detail in details:
            if isinstance(detail, dict):
                label = detail.get("label")
                if label:
                    labels.append(str(label))
        if labels:
            return labels
    legacy = item.get(legacy_key, []) or []
    return [str(value) for value in legacy if value not in (None, "")]




def relation_annual_labels(item: Dict[str, object]) -> List[str]:
    details = item.get("annual_star_details", []) or []
    labels = []
    for detail in details:
        if isinstance(detail, dict) and detail.get("label"):
            labels.append(str(detail["label"]))
    if labels:
        return labels
    return [str(value) for value in (item.get("annual_stars", []) or []) if value]

def relation_trang_sinh_label(item: Dict[str, object]) -> str:
    detail = item.get("trang_sinh_detail")
    if isinstance(detail, dict) and detail.get("label"):
        return str(detail["label"])
    return str(item.get("trang_sinh") or "—")

def relation_item_summary(item: Dict[str, object]) -> str:
    major = _join(relation_star_labels(item, "major"), "Vô chính diệu")
    good = _join(relation_star_labels(item, "good"))
    bad = _join(relation_star_labels(item, "bad"))
    transformations = _join(relation_star_labels(item, "transformations"))
    annual = _join(relation_annual_labels(item))
    trang_sinh = relation_trang_sinh_label(item)
    flags = []
    if item.get("tuan"):
        flags.append("Tuần")
    if item.get("triet"):
        flags.append("Triệt")
    flag_text = _join(flags)
    return (
        f"{item.get('palace', '—')} tại {item.get('branch', '—')} | "
        f"Chính tinh: {major} | Sao tốt: {good} | Sao xấu: {bad} | "
        f"Tứ Hóa: {transformations} | Lưu niên: {annual} | Tràng Sinh: {trang_sinh} | "
        f"Tuần/Triệt: {flag_text}"
    )


def tu_vi_fact_lines(relation: Dict[str, object]) -> List[str]:
    lines = ["Bản cung: " + relation_item_summary(relation["self"])]
    lines.append("Đối cung: " + relation_item_summary(relation["opposite"]))
    lines.append(
        "Tam hợp: " + " || ".join(relation_item_summary(item) for item in relation["trine"])
    )
    lines.append(
        "Giáp cung: " + " || ".join(relation_item_summary(item) for item in relation["adjacent"])
    )
    return lines


def _format_pillar(value: Dict[str, object]) -> str:
    hidden = value.get("hidden_stems", []) or []
    hidden_text = _join(
        f"{item.get('stem', '—')} ({item.get('ten_god', '—')})" for item in hidden
    )
    return (
        f"{value.get('text', '—')} | {value.get('yin_yang', '—')} "
        f"{value.get('stem_element', '—')} | Thập thần: {value.get('ten_god', '—')} | "
        f"Tàng can: {hidden_text}"
    )


def _format_ten_god_group(value: Dict[str, object]) -> str:
    items = value.get("items", {}) or {}
    parts = [f"{name}: {amount}" for name, amount in items.items()]
    return f"{_join(parts)} | Tổng: {value.get('total', 0)}"


def _format_day_master(value: Dict[str, object]) -> str:
    return (
        f"{value.get('stem', '—')} — {value.get('yin_yang', '—')} {value.get('element', '—')} | "
        f"Cường nhược sơ bộ: {value.get('preliminary_strength', '—')} | "
        f"Trợ thân: {value.get('support_ratio_percent', '—')}%"
    )


def _format_luck_cycles(value: Dict[str, object]) -> str:
    cycles = value.get("cycles", []) or []
    cycle_text = _join(
        f"{item.get('text', '—')} ({item.get('start_age', '—')}–{item.get('end_age', '—')} tuổi)"
        for item in cycles
    )
    return (
        f"{value.get('direction', '—')} | Khởi vận {value.get('start_age_text', '—')} | "
        f"{cycle_text}"
    )


def _format_element_balance(value: Dict[str, object]) -> str:
    percentages = value.get("percentages", value) or {}
    if not isinstance(percentages, dict):
        return str(percentages)
    return _join(f"{name}: {amount}%" for name, amount in percentages.items())


def format_bazi_value(key: str, value: object) -> str:
    if isinstance(value, dict):
        if key == "day_master" or {"stem", "element", "preliminary_strength"}.issubset(value):
            return _format_day_master(value)
        if "text" in value and "hidden_stems" in value:
            return _format_pillar(value)
        if "items" in value and "total" in value:
            return _format_ten_god_group(value)
        if key == "luck_cycles" or "cycles" in value:
            return _format_luck_cycles(value)
        if key == "element_balance" or "percentages" in value:
            return _format_element_balance(value)
        return _join(f"{LABELS.get(k, k)}: {format_bazi_value(k, v)}" for k, v in value.items())
    if isinstance(value, list):
        return _join(value)
    if isinstance(value, float):
        return f"{value:.2f}".rstrip("0").rstrip(".")
    return str(value)


def bazi_fact_rows(facts: Dict[str, object]) -> List[Tuple[str, str]]:
    return [
        (LABELS.get(key, key.replace("_", " ").title()), format_bazi_value(key, value))
        for key, value in facts.items()
    ]


def topic_focus(topic_name: str) -> str:
    return FOCUS_BY_TOPIC.get(
        topic_name,
        "So sánh hai nhóm dữ kiện theo cùng chủ đề; ghi rõ điểm đồng quy và điểm cần điều kiện hóa.",
    )


def combined_topic_text(topic: Dict[str, object]) -> str:
    lines = [str(topic["topic"]).upper(), "=" * 92, "TỬ VI"]
    for index, relation in enumerate(topic.get("tu_vi_facts", []), start=1):
        lines.append(f"[{index}] {relation['self']['palace']} tại {relation['self']['branch']}")
        lines.extend(f"  {line}" for line in tu_vi_fact_lines(relation))
    lines.extend(["", "BÁT TỰ"])
    for label, value in bazi_fact_rows(topic.get("bat_tu_facts", {})):
        lines.append(f"  {label}: {value}")
    lines.extend([
        "",
        "ĐỐI CHIẾU",
        "  " + topic_focus(str(topic["topic"])),
        "  Khi hai hệ cùng hướng: tăng độ tin cậy của nhận định.",
        "  Khi hai hệ khác hướng: giữ cả hai điều kiện, không ép thành kết luận tốt/xấu tuyệt đối.",
    ])
    return "\n".join(lines)


def cross_system_signal_text(signals: List[Dict[str, object]]) -> str:
    lines = ["TÍN HIỆU GIAO THOA NGŨ HÀNH", "=" * 92]
    for signal in signals:
        lines.append(
            f"- {signal.get('code', '—')}: Tử Vi {signal.get('tu_vi') or '—'} | "
            f"Bát Tự {signal.get('bat_tu') or '—'} | {signal.get('relation', '—')}"
        )
        if signal.get("note"):
            lines.append(f"  {signal['note']}")
    return "\n".join(lines)


def all_combined_text(combined: Dict[str, object]) -> str:
    blocks = [
        "TỔNG HỢP TỬ VI + BÁT TỰ",
        "#" * 92,
        str(combined.get("principle", "")),
        cross_system_signal_text(combined.get("cross_system_signals", [])),
    ]
    blocks.extend(combined_topic_text(topic) for topic in combined.get("topics", []))
    blocks.append(
        "Dữ liệu được trình bày theo từng chủ đề để đưa vào Rule Matcher hoặc AI; "
        "không hiển thị JSON trong phần tổng hợp."
    )
    return "\n\n\n".join(blocks)
