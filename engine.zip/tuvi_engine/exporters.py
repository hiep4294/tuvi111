# -*- coding: utf-8 -*-
import html
import json
from pathlib import Path

from tuvi_engine.models import ChartData
from tuvi_engine.combined_presentation import (
    bazi_fact_rows,
    relation_item_summary,
    relation_star_labels,
    relation_annual_labels,
    relation_trang_sinh_label,
    topic_focus,
)
from tuvi_engine.presentation import (
    ELEMENT_COLORS,
    element_legend_text,
    split_palace_stars,
    star_element_code,
)


GRID = {
    6: (0, 0), 7: (0, 1), 8: (0, 2), 9: (0, 3),
    5: (1, 0), 10: (1, 3),
    4: (2, 0), 11: (2, 3),
    3: (3, 0), 2: (3, 1), 1: (3, 2), 12: (3, 3),
}


def save_json(chart: ChartData, path: str):
    Path(path).write_text(
        json.dumps(chart.to_dict(), ensure_ascii=False, indent=2),
        encoding="utf-8",
    )


def save_html(chart: ChartData, path: str):
    p_by_id = {p.branch_id: p for p in chart.palaces}
    cells = []
    for branch, (row, col) in GRID.items():
        p = p_by_id[branch]
        groups = split_palace_stars(p.stars)
        major = _star_html(groups["main"])
        good = _star_html(groups["good"] + groups["neutral"])
        bad = _star_html(groups["bad"])
        trang_sinh = groups["trang_sinh"]
        trang_sinh_name = trang_sinh.get("saoTen", "—") if trang_sinh else "—"
        annual = _star_html(p.annual_stars) or "—"
        cells.append(f"""
        <section class="palace" style="grid-row:{row+1};grid-column:{col+1}">
          <header><b>{html.escape(p.palace_name)}</b> — {html.escape(p.branch_name)} ({html.escape(p.element)})</header>
          <div class="marker-row">
            <span class="tuan-badge">{'TUẦN' if p.has_tuan else ''}</span>
            <span class="than-badge">{'THÂN' if p.is_body else ''}</span>
            <span class="triet-badge">{'TRIỆT' if p.has_triet else ''}</span>
          </div>
          <div class="major">{major}</div>
          <div class="star-columns">
            <div class="star-side good-side"><div class="star-heading">SAO TỐT</div><div class="star-list">{good}</div></div>
            <div class="star-side bad-side"><div class="star-heading">SAO XẤU</div><div class="star-list">{bad}</div></div>
          </div>
          <div class="annual-stars"><b>LƯU NIÊN {chart.annual['year']} · {html.escape(chart.annual['year_can_chi'])}</b><br>{annual}</div>
          <footer>
            <span class="limit major-limit">Đại hạn: {p.major_limit}</span>
            <span class="trang-sinh">{html.escape(trang_sinh_name)}</span>
            <span class="limit minor-limit">Tiểu hạn: {html.escape(p.minor_limit)}</span>
          </footer>
        </section>""")

    h = chart.heaven
    rollover = " · Tính sang ngày kế tiếp từ 23:00" if h["rolled_at_23"] else ""
    center = f"""
    <section class="center">
      <h1>LÁ SỐ TỬ VI</h1>
      <h2>{html.escape(str(h['name']))} — {html.escape(str(h['gender']))}</h2>
      <p>Giờ nhập: {html.escape(str(h['input_time']))}{html.escape(rollover)}<br>
      Dương lịch hiệu dụng: {h['solar_date']}<br>
      Âm lịch: {h['lunar_date']} · Dữ liệu an sao: {h['chart_lunar_date']}<br>
      Năm {h['year_can_chi']} · Tháng {h['month_can_chi']} · Ngày {h['day_can_chi']} · Giờ {h['hour_can_chi']}</p>
      <p><b>{html.escape(str(h['ban_menh']))}</b><br>{h['cuc']} · {h['menh_cuc_relation']}<br>
      {h['am_duong_menh']} · Mệnh chủ {h['menh_chu']} · Thân chủ {h['than_chu']}<br>
      Bảng Tứ Hóa: {html.escape(str(h['rule_profile']))}<br>
      Bộ an sao: {html.escape(str(h['placement_profile_label']))}<br>
      Lưu niên: {h['annual_year']} · {html.escape(str(h['annual_year_can_chi']))}</p>
      <p><b>Kiểm định an sao:</b> lá số 17:18 ngày 18/05/2023 đã được khóa làm mẫu hồi quy; Ân Quang–Thiên Quý, Lưu Hà–Thiên Trù và bảng trạng thái đầy đủ của mọi phụ tinh vẫn cần thêm mẫu đối chiếu.</p>
      <p><b>Không hiệu chỉnh giờ sinh.</b></p>
      <p><b>Màu sao theo Ngũ Hành:</b> {html.escape(element_legend_text())}</p>
      <p>Chart ID: {chart.chart_id} · Engine: {html.escape(chart.engine_version)}</p>
    </section>"""

    star_element_by_name = {
        star.get("saoTen", ""): star_element_code(star)
        for palace in chart.palaces
        for star in [*palace.stars, *palace.annual_stars]
        if star.get("saoTen")
    }
    relation_rows = []
    for p in chart.palaces:
        r = chart.relations[str(p.branch_id)]
        relation_rows.append(
            f"<tr class=\"relation-row\"><td>{html.escape(p.palace_name)}<br><small>{html.escape(p.branch_name)}</small></td>"
            f"<td>{_relation_cell(r['self'], star_element_by_name)}</td>"
            f"<td>{_relation_cell(r['opposite'], star_element_by_name)}</td>"
            f"<td>{'<hr>'.join(_relation_cell(x, star_element_by_name) for x in r['trine'])}</td>"
            f"<td>{'<hr>'.join(_relation_cell(x, star_element_by_name) for x in r['adjacent'])}</td>"
            f"<td>{_relation_cell(r['six_harmony'], star_element_by_name)}</td>"
            f"<td>{_relation_cell(r['harm'], star_element_by_name)}</td>"
            f"<td>{_relation_cell(r['break'], star_element_by_name)}</td></tr>"
        )

    document = f"""<!doctype html><html lang="vi"><head><meta charset="utf-8">
<title>Tử Vi + Bát Tự - {html.escape(str(h['name']))}</title>
<style>
@page{{size:A3 landscape;margin:8mm}}
*{{box-sizing:border-box}}
body{{font-family:Arial,sans-serif;margin:18px;color:#222}}
.joint-title{{margin:0 0 10px;padding:10px;background:#6e2e1b;color:#fff;text-align:center}}
.chart{{display:grid;grid-template-columns:repeat(4,1fr);grid-template-rows:repeat(4,minmax(235px,auto));gap:5px}}
.palace,.center{{border:1.4px solid #333;padding:8px;overflow:hidden}}
.palace{{display:flex;flex-direction:column}}
.center{{grid-row:2/4;grid-column:2/4;text-align:center;padding:25px}}
header{{font-size:16px;background:#f3ead7;padding:4px}}
.marker-row{{display:grid;grid-template-columns:1fr 1fr 1fr;min-height:19px;margin-top:3px;font-size:11px;font-weight:bold}}
.marker-row span{{padding:3px 4px}}
.tuan-badge{{text-align:left;color:#6b21a8;background:#f2e9ff}}
.than-badge{{text-align:center;color:#8a5a00;background:#fff7d6}}
.triet-badge{{text-align:right;color:#a11a1a;background:#ffe9e9}}
.marker-row span:empty{{background:transparent}}
.major{{font-size:17px;font-weight:bold;color:#9b1c1c;margin:8px 0;text-align:center;white-space:pre-line;min-height:20px}}
.star-columns{{display:grid;grid-template-columns:1fr 1fr;gap:8px;flex:1;min-height:78px}}
.star-side{{font-size:12px;line-height:1.35;white-space:pre-line}}
.star-heading{{font-size:10px;font-weight:bold;padding:3px 4px;margin-bottom:4px}}
.good-side{{text-align:left;color:#165b36;border-right:1px solid #ddd;padding-right:4px}}
.good-side .star-heading{{background:#eef8f0;color:#12613a;text-align:left}}
.bad-side{{text-align:right;color:#8f1d1d;padding-left:4px}}
.bad-side .star-heading{{background:#fff0ee;color:#9b1c1c;text-align:right}}
.star-list{{overflow-wrap:anywhere}}
.annual-stars{{font-size:11px;line-height:1.35;padding:5px;margin-top:4px;background:#eef5ff;border:1px solid #bfdbfe}}
.annual-stars b{{color:#174a7e}}
.element-K{{color:#6B7280;}}
.element-M{{color:#15803D;}}
.element-T{{color:#1D4ED8;}}
.element-H{{color:#DC2626;}}
.element-O{{color:#A16207;}}
footer{{display:grid;grid-template-columns:1fr 1fr 1fr;align-items:center;font-size:11px;margin-top:8px;border-top:1px solid #aaa;background:#f4efe5}}
footer span{{padding:5px 4px}}
.major-limit{{text-align:left}}.minor-limit{{text-align:right}}
.trang-sinh{{text-align:center;font-weight:bold;color:#6e2e1b;background:#eee4d1}}
table{{border-collapse:collapse;width:100%;margin-top:25px;font-size:12px}}td,th{{border:1px solid #999;padding:6px;vertical-align:top}}th{{background:#eee4d1}}
td small{{color:#666}}td hr{{border:0;border-top:1px solid #ddd;margin:5px 0}}
.notice{{margin-top:16px;padding:10px;background:#fff8d8;border:1px solid #d8bf57}}
.bazi-grid{{display:grid;grid-template-columns:repeat(4,1fr);gap:8px;margin:10px 0 18px}}
.pillar{{border:1px solid #777;padding:10px;text-align:center;background:#faf7ef}}
.pillar .big{{font-size:24px;font-weight:bold;color:#6e2e1b;margin:5px 0}}
.data-box{{border:1px solid #aaa;padding:10px;margin:8px 0;background:#fafafa;white-space:pre-wrap}}
.topic{{border:1px solid #aaa;padding:10px;margin:12px 0;background:#fff}}
.topic-grid{{display:grid;grid-template-columns:1fr 1fr 1fr;gap:8px}}
.topic-column{{border:1px solid #c8c8c8;padding:8px;background:#fafafa}}
.topic-column h4{{margin:0 0 7px;padding:5px;background:#eee4d1}}
.fact-row{{margin:5px 0;padding-bottom:5px;border-bottom:1px dotted #ccc}}
</style></head><body><h1 class="joint-title">TỬ VI + BÁT TỰ</h1><div class="chart">{''.join(cells)}{center}</div>
{_bazi_html(chart)}
<div class="notice"><b>Lưu ý:</b> Dùng trực tiếp giờ sinh được nhập, không hiệu chỉnh theo kinh độ hoặc giờ mặt trời. Tử Vi và Bát Tự là hệ thống huyền học truyền thống, không phải tư vấn khoa học.</div>
<h2>Quan hệ đầy đủ của 12 cung</h2><table><thead><tr><th>Cung đang xét</th><th>Bản cung</th><th>Đối cung / lục xung</th><th>Tam hợp</th><th>Giáp cung</th><th>Nhị hợp</th><th>Tương hại</th><th>Tương phá</th></tr></thead><tbody>{''.join(relation_rows)}</tbody></table>
{_combined_html(chart)}
</body></html>"""
    Path(path).write_text(document, encoding="utf-8")


def _star_names_html(names, element_by_name):
    if not names:
        return "—"
    parts = []
    for name in names:
        code = element_by_name.get(name, "")
        class_name = f"element-{code}" if code else ""
        parts.append(f'<span class="{class_name}">{html.escape(name)}</span>')
    return ", ".join(parts)


def _star_details_html(details, fallback_names, element_by_name):
    if details:
        parts = []
        for detail in details:
            name = str(detail.get("name", ""))
            element_name = str(detail.get("element_name", "Chưa xác định"))
            code = str(detail.get("element_code", ""))
            class_name = f"element-{code}" if code else ""
            label = f"{name} ({element_name})" if name else ""
            if label:
                parts.append(f'<span class="{class_name}">{html.escape(label)}</span>')
        if parts:
            return ", ".join(parts)
    return _star_names_html(fallback_names, element_by_name)


def _relation_summary_html(item, element_by_name):
    major = _star_details_html(
        item.get("major_star_details", []), item.get("major_stars", []), element_by_name
    )
    if not item.get("major_star_details") and not item.get("major_stars"):
        major = "Vô chính diệu"
    good = _star_details_html(
        item.get("good_star_details", []), item.get("good_stars", []), element_by_name
    )
    bad = _star_details_html(
        item.get("bad_star_details", []), item.get("bad_stars", []), element_by_name
    )
    transformations = _star_details_html(
        item.get("transformation_details", []), item.get("transformations", []), element_by_name
    )
    annual = _star_details_html(
        item.get("annual_star_details", []), item.get("annual_stars", []), element_by_name
    )
    trang_detail = item.get("trang_sinh_detail") or {}
    trang_name = str(trang_detail.get("name", item.get("trang_sinh") or "—"))
    trang_element = str(trang_detail.get("element_name", ""))
    trang_code = str(trang_detail.get("element_code", ""))
    trang_label = f"{trang_name} ({trang_element})" if trang_element else trang_name
    trang_class = f"element-{trang_code}" if trang_code else ""
    trang_html = f'<span class="{trang_class}">{html.escape(trang_label)}</span>'
    flags = []
    if item.get("tuan"):
        flags.append("Tuần")
    if item.get("triet"):
        flags.append("Triệt")
    flag_text = " · ".join(flags) if flags else "—"
    return (
        f"<b>{html.escape(str(item.get('palace', '—')))}</b> tại {html.escape(str(item.get('branch', '—')))}"
        f"<br><b>Chính tinh:</b> {major}"
        f"<br><b>Sao tốt:</b> {good}"
        f"<br><b>Sao xấu:</b> {bad}"
        f"<br><b>Tứ Hóa:</b> {transformations}"
        f"<br><b>Lưu niên:</b> {annual}"
        f"<br><b>Tràng Sinh:</b> {trang_html}"
        f"<br><b>Tuần/Triệt:</b> {html.escape(flag_text)}"
    )


def _relation_cell(item, element_by_name):
    content = _relation_summary_html(item, element_by_name)
    return content


def _star_html(stars):
    parts = []
    for star in stars:
        dignity = star.get("saoDacTinh")
        text = f"{star.get('saoTen', '')}" + (f" ({dignity})" if dignity else "")
        code = star_element_code(star)
        class_name = f"element-{code}" if code else ""
        parts.append(f'<span class="{class_name}">{html.escape(text)}</span>')
    return " · ".join(parts)


def _bazi_html(chart: ChartData) -> str:
    b = chart.bazi
    pillars = []
    for pillar in b["pillars"]:
        hidden = ", ".join(
            f"{item['stem']} ({item['ten_god']})" for item in pillar["hidden_stems"]
        )
        pillars.append(
            f"<div class='pillar'><b>{html.escape(pillar['label'])}</b>"
            f"<div class='big'>{html.escape(pillar['text'])}</div>"
            f"<div>{html.escape(pillar['yin_yang'])} {html.escape(pillar['stem_element'])}</div>"
            f"<div>{html.escape(pillar['ten_god'])}</div>"
            f"<small>Tàng can: {html.escape(hidden)}</small></div>"
        )
    dm = b["day_master"]
    balance = " · ".join(
        f"{key}: {value}%" for key, value in b["element_balance"]["percentages"].items()
    )
    gods = " · ".join(
        f"{key}: {value}" for key, value in b["ten_god_distribution"].items()
    )
    luck_rows = "".join(
        f"<tr><td>{cycle['index']}</td><td>{html.escape(cycle['text'])}</td>"
        f"<td>{cycle['start_age']}</td><td>{cycle['end_age']}</td></tr>"
        for cycle in b["luck_cycles"]["cycles"]
    )
    return f"""
    <h2>Bát Tự / Tứ Trụ</h2>
    <p>Thời điểm dương lịch: {html.escape(b['birth_solar_datetime'])} · Năm Bát Tự: {b['bazi_year']} · Cách tính tháng: {html.escape(b['month_method_name'])} · Căn cứ: {html.escape(b['month_basis_label'])}</p>
    <div class='bazi-grid'>{''.join(pillars)}</div>
    <div class='data-box'><b>Nhật chủ:</b> {html.escape(dm['stem'])} — {html.escape(dm['yin_yang'])} {html.escape(dm['element'])}<br>
    <b>Cường nhược sơ bộ:</b> {html.escape(dm['preliminary_strength'])} · Trợ thân {dm['support_ratio_percent']}%<br>
    <b>Ngũ hành:</b> {html.escape(balance)}<br>
    <b>Thập thần:</b> {html.escape(gods)}<br>
    <b>Cảnh báo:</b> {html.escape(dm['warning'])}</div>
    <h3>Đại vận — {html.escape(b['luck_cycles']['direction'])}, khởi vận {html.escape(b['luck_cycles']['start_age_text'])}</h3>
    <table><thead><tr><th>#</th><th>Trụ đại vận</th><th>Từ tuổi</th><th>Đến tuổi</th></tr></thead><tbody>{luck_rows}</tbody></table>
    """



def _element_map(chart: ChartData):
    return {
        star.get("saoTen", ""): star_element_code(star)
        for palace in chart.palaces
        for star in [*palace.stars, *palace.annual_stars]
        if star.get("saoTen")
    }

def _combined_html(chart: ChartData) -> str:
    c = chart.combined_analysis
    signal_items = "".join(
        f"<li><b>{html.escape(str(item['code']))}</b>: "
        f"Tử Vi {html.escape(str(item.get('tu_vi') or '—'))} · "
        f"Bát Tự {html.escape(str(item.get('bat_tu') or '—'))} · "
        f"{html.escape(str(item['relation']))}"
        + (f"<br><small>{html.escape(str(item['note']))}</small>" if item.get('note') else "")
        + "</li>"
        for item in c["cross_system_signals"]
    )
    topic_blocks = []
    for topic in c["topics"]:
        tuvi_rows = []
        for relation in topic["tu_vi_facts"]:
            tuvi_rows.append(
                "<div class='fact-row'><b>Bản cung:</b> "
                + _relation_summary_html(relation["self"], _element_map(chart))
                + "</div>"
            )
            tuvi_rows.append(
                "<div class='fact-row'><b>Đối cung:</b> "
                + _relation_summary_html(relation["opposite"], _element_map(chart))
                + "</div>"
            )
            tuvi_rows.append(
                "<div class='fact-row'><b>Tam hợp:</b> "
                + "<br><br>".join(_relation_summary_html(item, _element_map(chart)) for item in relation["trine"])
                + "</div>"
            )
            tuvi_rows.append(
                "<div class='fact-row'><b>Giáp cung:</b> "
                + "<br><br>".join(_relation_summary_html(item, _element_map(chart)) for item in relation["adjacent"])
                + "</div>"
            )
        bazi_rows = "".join(
            f"<div class='fact-row'><b>{html.escape(label)}:</b> {html.escape(value)}</div>"
            for label, value in bazi_fact_rows(topic["bat_tu_facts"])
        )
        comparison = (
            f"<div class='fact-row'>{html.escape(topic_focus(topic['topic']))}</div>"
            "<div class='fact-row'>Hai hệ cùng hướng: tăng độ tin cậy của nhận định.</div>"
            "<div class='fact-row'>Hai hệ khác hướng: giữ cả hai điều kiện, không ép thành tốt/xấu tuyệt đối.</div>"
        )
        topic_blocks.append(
            f"<section class='topic'><h3>{html.escape(topic['topic'])}</h3>"
            "<div class='topic-grid'>"
            f"<div class='topic-column'><h4>TỬ VI</h4>{''.join(tuvi_rows)}</div>"
            f"<div class='topic-column'><h4>BÁT TỰ</h4>{bazi_rows}</div>"
            f"<div class='topic-column'><h4>ĐỐI CHIẾU</h4>{comparison}</div>"
            "</div></section>"
        )
    return f"""
    <h2>Tổng hợp Tử Vi + Bát Tự theo 7 chủ đề</h2>
    <h3>Đối chiếu Tử Vi + Bát Tự</h3>
    <p>{html.escape(c['principle'])}</p>
    <h3>Tín hiệu giao thoa Ngũ Hành</h3><ul>{signal_items}</ul>
    {''.join(topic_blocks)}
    """
