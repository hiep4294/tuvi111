# -*- coding: utf-8 -*-
"""Structured bridge between Tử Vi and Bát Tự.

The bridge does not force both traditions into one score. It exposes the
relevant facts for each life topic so a rule engine or AI can compare them
without inventing palace geometry, stars, pillars, or Ten Gods.
"""
from __future__ import annotations

import unicodedata
from typing import Dict, Iterable, List, Optional

ELEMENTS = ["Mộc", "Hỏa", "Thổ", "Kim", "Thủy"]


def _fold(text: str) -> str:
    normalized = unicodedata.normalize("NFD", text or "")
    return "".join(ch for ch in normalized if unicodedata.category(ch) != "Mn").casefold()


def _find_palace(palaces: Iterable[object], name: str):
    target = _fold(name)
    for palace in palaces:
        if _fold(getattr(palace, "palace_name", "")) == target:
            return palace
    return None


def _relation_for(chart, palace_name: str) -> Optional[Dict[str, object]]:
    palace = _find_palace(chart.palaces, palace_name)
    if not palace:
        return None
    return chart.relations.get(str(palace.branch_id))


def _extract_element(text: str) -> Optional[str]:
    folded = _fold(text)
    for element in ELEMENTS:
        if _fold(element) in folded:
            return element
    return None


def _ten_god_group(distribution: Dict[str, float], names: List[str]) -> Dict[str, object]:
    values = {name: distribution.get(name, 0.0) for name in names}
    return {"items": values, "total": round(sum(values.values()), 2)}


def build_combined_analysis(chart) -> Dict[str, object]:
    bazi = chart.bazi
    distribution = bazi["ten_god_distribution"]
    day_master = bazi["day_master"]
    balance = bazi["element_balance"]
    gender = chart.input.gender

    spouse_names = ["Chính Tài", "Thiên Tài"] if gender == 1 else ["Chính Quan", "Thất Sát"]
    tuvi_menh_element = _extract_element(chart.heaven.get("ban_menh", ""))
    tuvi_cuc_element = _extract_element(chart.heaven.get("cuc", ""))
    bazi_dm_element = day_master["element"]
    dominant_element = balance["dominant"]

    signals = []
    if tuvi_menh_element:
        signals.append({
            "code": "MENH_NAP_AM_VS_DAY_MASTER",
            "tu_vi": tuvi_menh_element,
            "bat_tu": bazi_dm_element,
            "relation": "Trùng hành" if tuvi_menh_element == bazi_dm_element else "Khác hành",
            "note": "Nạp âm năm sinh và Nhật chủ là hai lớp khác nhau; chỉ dùng làm tín hiệu đối chiếu.",
        })
    if tuvi_cuc_element:
        signals.append({
            "code": "CUC_VS_DAY_MASTER",
            "tu_vi": tuvi_cuc_element,
            "bat_tu": bazi_dm_element,
            "relation": "Trùng hành" if tuvi_cuc_element == bazi_dm_element else "Khác hành",
        })
    signals.append({
        "code": "CUC_VS_BAZI_DOMINANT",
        "tu_vi": tuvi_cuc_element,
        "bat_tu": dominant_element,
        "relation": "Trùng hành" if tuvi_cuc_element == dominant_element else "Khác hành",
    })

    topics = [
        {
            "topic": "Bản thân và khí chất",
            "tu_vi_palaces": ["Mệnh"],
            "tu_vi_facts": [_relation_for(chart, "Mệnh")],
            "bat_tu_facts": {
                "day_master": day_master,
                "month_pillar": bazi["pillars"][1],
                "element_balance": balance["percentages"],
                "peer_resource": _ten_god_group(distribution, ["Tỷ Kiên", "Kiếp Tài", "Chính Ấn", "Thiên Ấn"]),
            },
        },
        {
            "topic": "Sự nghiệp và năng lực làm việc",
            "tu_vi_palaces": ["Quan Lộc", "Mệnh"],
            "tu_vi_facts": [_relation_for(chart, "Quan Lộc"), _relation_for(chart, "Mệnh")],
            "bat_tu_facts": {
                "officer": _ten_god_group(distribution, ["Chính Quan", "Thất Sát"]),
                "resource": _ten_god_group(distribution, ["Chính Ấn", "Thiên Ấn"]),
                "output": _ten_god_group(distribution, ["Thực Thần", "Thương Quan"]),
                "luck_cycles": bazi["luck_cycles"],
            },
        },
        {
            "topic": "Tài chính và khả năng tạo nguồn lực",
            "tu_vi_palaces": ["Tài Bạch", "Điền Trạch"],
            "tu_vi_facts": [_relation_for(chart, "Tài Bạch"), _relation_for(chart, "Điền Trạch")],
            "bat_tu_facts": {
                "wealth": _ten_god_group(distribution, ["Chính Tài", "Thiên Tài"]),
                "output": _ten_god_group(distribution, ["Thực Thần", "Thương Quan"]),
                "wealth_element": ELEMENTS[(ELEMENTS.index(bazi_dm_element) + 2) % 5],
            },
        },
        {
            "topic": "Hôn nhân và quan hệ gắn bó",
            "tu_vi_palaces": ["Phu Thê"],
            "tu_vi_facts": [_relation_for(chart, "Phu Thê")],
            "bat_tu_facts": {
                "day_branch_spouse_palace": bazi["pillars"][2]["branch"],
                "spouse_ten_gods": _ten_god_group(distribution, spouse_names),
                "spouse_rule": "Nam xét Tài; Nữ xét Quan/Sát trong lớp đối chiếu sơ bộ.",
            },
        },
        {
            "topic": "Gia đình, nền tảng và phúc khí",
            "tu_vi_palaces": ["Phụ Mẫu", "Phúc Đức", "Điền Trạch"],
            "tu_vi_facts": [
                _relation_for(chart, "Phụ Mẫu"),
                _relation_for(chart, "Phúc Đức"),
                _relation_for(chart, "Điền Trạch"),
            ],
            "bat_tu_facts": {
                "year_pillar": bazi["pillars"][0],
                "month_pillar": bazi["pillars"][1],
                "resource": _ten_god_group(distribution, ["Chính Ấn", "Thiên Ấn"]),
            },
        },
        {
            "topic": "Sức khỏe và cân bằng thể chất",
            "tu_vi_palaces": ["Tật Ách"],
            "tu_vi_facts": [_relation_for(chart, "Tật Ách")],
            "bat_tu_facts": {
                "element_balance": balance["percentages"],
                "dominant_element": dominant_element,
                "weakest_element": balance["weakest"],
                "warning": "Chỉ là dữ kiện huyền học, không dùng chẩn đoán bệnh.",
            },
        },
        {
            "topic": "Môi trường xã hội và dịch chuyển",
            "tu_vi_palaces": ["Thiên Di", "Nô Bộc"],
            "tu_vi_facts": [_relation_for(chart, "Thiên Di"), _relation_for(chart, "Nô Bộc")],
            "bat_tu_facts": {
                "output": _ten_god_group(distribution, ["Thực Thần", "Thương Quan"]),
                "peer": _ten_god_group(distribution, ["Tỷ Kiên", "Kiếp Tài"]),
                "hour_pillar": bazi["pillars"][3],
            },
        },
    ]

    # Remove nulls defensively if a source engine uses a different palace label.
    for topic in topics:
        topic["tu_vi_facts"] = [item for item in topic["tu_vi_facts"] if item]

    return {
        "engine_version": "tuvi-bazi-bridge-0.6.0",
        "principle": "Giữ Tử Vi và Bát Tự độc lập, chỉ đối chiếu theo từng chủ đề; không cộng thành một điểm số tuyệt đối.",
        "cross_system_signals": signals,
        "topics": topics,
        "ai_contract": {
            "must_use_only_supplied_facts": True,
            "must_separate_tu_vi_and_bat_tu_evidence": True,
            "must_explain_agreement_and_conflict": True,
            "must_not_invent_stars_pillars_or_relations": True,
            "must_not_make_medical_legal_financial_certainties": True,
            "recommended_structure": [
                "Dữ kiện Tử Vi",
                "Dữ kiện Bát Tự",
                "Điểm đồng quy",
                "Điểm khác biệt hoặc điều kiện hóa",
                "Kết luận có mức độ, không tuyệt đối",
            ],
        },
    }
