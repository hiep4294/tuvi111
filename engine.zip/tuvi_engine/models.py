# -*- coding: utf-8 -*-
from dataclasses import asdict, dataclass
from datetime import date, datetime
from typing import Any, Dict, List


@dataclass(frozen=True)
class BirthInput:
    name: str
    gender: int  # 1 male, -1 female
    calendar_type: str  # "solar" or "lunar"
    day: int
    month: int
    year: int
    hour: int
    minute: int
    is_leap_month: bool = False
    bazi_month_method: str = "jieqi"  # mặc định cố định theo tiết khí
    tu_hoa_method: str = "nam_phai_viet"  # nam_phai_viet | toan_thu | toan_tap
    placement_profile: str = "tracuutuvi_reference"  # bộ an sao tham chiếu
    annual_year: int = 2026


@dataclass(frozen=True)
class NormalizedBirth:
    input_solar_datetime: datetime
    rolled_at_23: bool
    effective_solar_date: date
    lunar_day: int
    lunar_month: int
    lunar_year: int
    lunar_leap: bool
    chart_lunar_day: int
    chart_lunar_month: int
    chart_lunar_year: int
    hour_branch: int

    def to_dict(self) -> Dict[str, Any]:
        data = asdict(self)
        for key, value in list(data.items()):
            if isinstance(value, (datetime, date)):
                data[key] = value.isoformat()
        return data


@dataclass
class PalaceData:
    branch_id: int
    branch_name: str
    element: str
    palace_name: str
    is_body: bool
    major_limit: int
    minor_limit: str
    has_tuan: bool
    has_triet: bool
    stars: List[Dict[str, Any]]
    annual_stars: List[Dict[str, Any]]

    def to_dict(self) -> Dict[str, Any]:
        return asdict(self)


@dataclass
class ChartData:
    chart_id: int
    engine_version: str
    input: BirthInput
    normalized: NormalizedBirth
    heaven: Dict[str, Any]
    palaces: List[PalaceData]
    relations: Dict[str, Any]
    bazi: Dict[str, Any]
    combined_analysis: Dict[str, Any]
    annual: Dict[str, Any]

    def to_dict(self) -> Dict[str, Any]:
        return {
            "chart_id": self.chart_id,
            "engine_version": self.engine_version,
            "input": asdict(self.input),
            "normalized": self.normalized.to_dict(),
            "heaven": self.heaven,
            "palaces": [p.to_dict() for p in self.palaces],
            "relations": self.relations,
            "bazi": self.bazi,
            "combined_analysis": self.combined_analysis,
            "annual": self.annual,
        }
