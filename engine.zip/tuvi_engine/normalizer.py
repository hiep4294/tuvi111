# -*- coding: utf-8 -*-
from datetime import date, datetime, time, timedelta

from tuvi_engine.legacy.Lich_HND import L2S, S2L
from tuvi_engine.models import BirthInput, NormalizedBirth


class BirthDataError(ValueError):
    pass


def hour_to_branch(hour: int) -> int:
    """Map civil clock hour to the 12 Earthly Branch hours.

    Tý: 23:00-00:59, Sửu: 01:00-02:59, ..., Hợi: 21:00-22:59.
    """
    if not 0 <= hour <= 23:
        raise BirthDataError("Giờ phải nằm trong khoảng 0–23.")
    return (((hour + 1) // 2) % 12) + 1


def effective_leap_month(month: int, day: int, year: int, is_leap: bool):
    """Apply the project's leap-month convention.

    Leap-month day 1–15 uses the current month; day 16 onward uses the next
    month. Month 12 rolls to month 1 of the next lunar year.
    """
    if not is_leap or day <= 15:
        return month, year
    if month == 12:
        return 1, year + 1
    return month + 1, year


def _validate_lunar(day: int, month: int, year: int, leap: bool):
    if not (1 <= month <= 12 and 1 <= day <= 30 and 1600 <= year <= 2600):
        raise BirthDataError("Ngày âm lịch không hợp lệ hoặc ngoài phạm vi 1600–2600.")
    solar = L2S(day, month, year, 1 if leap else 0, 7)
    if solar == [0, 0, 0]:
        raise BirthDataError("Tháng nhuận không tồn tại trong năm đã chọn.")
    sd, sm, sy = solar
    check = S2L(sd, sm, sy, 7)
    if (
        check[0] != day
        or check[1] != month
        or check[2] != year
        or bool(check[3]) != bool(leap)
    ):
        raise BirthDataError("Ngày âm lịch không tồn tại trong tháng đã chọn.")
    return date(sy, sm, sd)


def normalize_birth(data: BirthInput) -> NormalizedBirth:
    """Normalize input without solar-time or longitude correction.

    The entered clock time is used directly. Per project convention, births
    from 23:00 through 23:59 are assigned to the following calendar day while
    retaining the Tý hour branch.
    """
    if data.gender not in (1, -1):
        raise BirthDataError("Giới tính không hợp lệ.")
    if data.tu_hoa_method not in {"nam_phai_viet", "toan_thu", "toan_tap"}:
        raise BirthDataError("Bảng Tứ Hóa không hợp lệ.")
    if data.placement_profile not in {"tracuutuvi_reference", "legacy_v1"}:
        raise BirthDataError("Bộ quy tắc an sao không hợp lệ.")
    if not (0 <= data.hour <= 23 and 0 <= data.minute <= 59):
        raise BirthDataError("Giờ/phút sinh không hợp lệ.")

    if data.calendar_type == "solar":
        try:
            input_date = date(data.year, data.month, data.day)
        except ValueError as exc:
            raise BirthDataError(str(exc)) from exc
    elif data.calendar_type == "lunar":
        input_date = _validate_lunar(
            data.day, data.month, data.year, data.is_leap_month
        )
    else:
        raise BirthDataError("Loại lịch phải là dương lịch hoặc âm lịch.")

    input_dt = datetime.combine(input_date, time(data.hour, data.minute))
    rolled = data.hour >= 23
    effective_date = input_date + (timedelta(days=1) if rolled else timedelta())

    lunar_day, lunar_month, lunar_year, lunar_leap = S2L(
        effective_date.day, effective_date.month, effective_date.year, 7
    )
    chart_month, chart_year = effective_leap_month(
        lunar_month, lunar_day, lunar_year, bool(lunar_leap)
    )

    return NormalizedBirth(
        input_solar_datetime=input_dt,
        rolled_at_23=rolled,
        effective_solar_date=effective_date,
        lunar_day=lunar_day,
        lunar_month=lunar_month,
        lunar_year=lunar_year,
        lunar_leap=bool(lunar_leap),
        chart_lunar_day=lunar_day,
        chart_lunar_month=chart_month,
        chart_lunar_year=chart_year,
        hour_branch=hour_to_branch(data.hour),
    )
