# -*- coding: utf-8 -*-
"""Helpers for classifying and presenting stars consistently."""
from typing import Any, Dict, Iterable, List, Optional


TRANG_SINH_IDS = set(range(39, 51))

# Màu chữ đủ đậm để đọc trên nền sáng. Kim dùng xám bạc thay vì trắng.
ELEMENT_COLORS = {
    "K": "#6B7280",  # Kim
    "M": "#15803D",  # Mộc
    "T": "#1D4ED8",  # Thủy
    "H": "#DC2626",  # Hỏa
    "O": "#A16207",  # Thổ
}
ELEMENT_NAMES = {
    "K": "Kim",
    "M": "Mộc",
    "T": "Thủy",
    "H": "Hỏa",
    "O": "Thổ",
}
DEFAULT_STAR_COLOR = "#333333"


def star_element_code(star: Dict[str, Any]) -> str:
    code = str(star.get("saoNguHanh", "")).upper()
    return code if code in ELEMENT_COLORS else ""


def star_element_name(star: Dict[str, Any]) -> str:
    return ELEMENT_NAMES.get(star_element_code(star), "Chưa xác định")


def star_color(star: Dict[str, Any]) -> str:
    return ELEMENT_COLORS.get(star_element_code(star), DEFAULT_STAR_COLOR)


def is_main_star(star: Dict[str, Any]) -> bool:
    return star.get("saoLoai") == 1


def is_trang_sinh_star(star: Dict[str, Any]) -> bool:
    return bool(star.get("vongTrangSinh")) or star.get("saoID") in TRANG_SINH_IDS


def is_good_star(star: Dict[str, Any]) -> bool:
    """Phân nhóm theo bảng sao của engine; chính tinh và Tràng Sinh tách riêng."""
    if is_main_star(star) or is_trang_sinh_star(star):
        return False
    star_type = star.get("saoLoai")
    return isinstance(star_type, (int, float)) and star_type < 10


def is_bad_star(star: Dict[str, Any]) -> bool:
    if is_main_star(star) or is_trang_sinh_star(star):
        return False
    star_type = star.get("saoLoai")
    return isinstance(star_type, (int, float)) and star_type > 10


def star_nature(star: Dict[str, Any]) -> str:
    if is_main_star(star):
        return "main"
    if is_trang_sinh_star(star):
        return "trang_sinh"
    if is_good_star(star):
        return "good"
    if is_bad_star(star):
        return "bad"
    return "neutral"


def split_palace_stars(stars: Iterable[Dict[str, Any]]) -> Dict[str, Any]:
    main: List[Dict[str, Any]] = []
    good: List[Dict[str, Any]] = []
    bad: List[Dict[str, Any]] = []
    neutral: List[Dict[str, Any]] = []
    trang_sinh: Optional[Dict[str, Any]] = None

    for star in stars:
        if is_trang_sinh_star(star):
            trang_sinh = star
        elif is_main_star(star):
            main.append(star)
        elif is_good_star(star):
            good.append(star)
        elif is_bad_star(star):
            bad.append(star)
        else:
            neutral.append(star)

    return {
        "main": main,
        "good": good,
        "bad": bad,
        "neutral": neutral,
        "trang_sinh": trang_sinh,
    }


def element_legend_text() -> str:
    return "Kim: xám bạc · Mộc: xanh lá · Thủy: xanh lam · Hỏa: đỏ · Thổ: nâu vàng"
