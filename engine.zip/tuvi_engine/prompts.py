# -*- coding: utf-8 -*-
"""Prompt profiles for AI-assisted Tử Vi and Bát Tự interpretation.

The prompts deliberately separate deterministic chart facts from narrative
interpretation. They are editable/copyable in the desktop UI; no AI call is
performed by this module.
"""
from __future__ import annotations

from typing import Dict, Iterable, List

from tuvi_engine.combined_presentation import (
    all_combined_text,
    combined_topic_text,
    cross_system_signal_text,
    relation_item_summary,
)

PROMPT_PROFILE_VERSION = "practical-critical-v1.13-auto-long"

BASE_PROMPT = """Bạn là chuyên gia phân tích Tử Vi và Bát Tự theo hướng thực tế, có tư duy phản biện.

NGUYÊN TẮC BẮT BUỘC
- Chỉ dùng dữ liệu được cung cấp; không tự thêm sao, cung, Can Chi, Tứ Hóa, Thập Thần hoặc quan hệ.
- Luận theo chuỗi: đặc tính cốt lõi → biểu hiện thực tế → lĩnh vực phát huy → điều kiện thuận/bất lợi → cách quản trị.
- Không quy một sao, một bộ sao hoặc một Thập Thần thành một nghề, tính cách hay sự kiện duy nhất.
- Không dùng câu tuyệt đối như: chỉ hợp, không thể, chắc chắn giàu/nghèo/ly hôn/mất nhà, khắc người thân hoặc mắc bệnh cụ thể.
- Phân biệt rõ: dữ liệu trực tiếp; suy luận có cơ sở; khả năng có điều kiện; phần chưa đủ dữ liệu.
- Sao tiền tố “L.” là sao lưu niên: chỉ dùng cho năm xem, không dùng để kết luận bản chất dài hạn.
- Tuần/Triệt phải luận hai mặt: làm chậm/gián đoạn/sửa đổi và giảm cực đoan/sàng lọc/tái cấu trúc.
- Nhị hợp, tương hại, tương phá chỉ là tín hiệu phụ; không được phủ định bản cung.
- Không chẩn đoán bệnh và không thay thế quyết định y tế, tài chính, pháp lý hoặc nghề nghiệp.
- Khi thiếu giới tính, giờ sinh, năm xem, đại hạn hoặc dữ liệu cần thiết, phải nêu rõ giới hạn.

PHONG CÁCH
Rõ, có chiều sâu, có ví dụ thực tế, không văn vẻ, không tâng bốc hoặc dọa nạt. Không chỉ liệt kê sao; phải giải thích cơ chế, điều kiện và cách ứng dụng. Với báo cáo toàn bộ, ưu tiên đầy đủ và có cấu trúc hơn sự ngắn gọn."""

RELATION_PRIORITY = """THỨ TỰ ƯU TIÊN
1. Bản cung và chính tinh.
2. Phụ tinh tại bản cung.
3. Tứ Hóa gốc.
4. Tuần/Triệt.
5. Đối cung.
6. Hai cung tam hợp.
7. Giáp cung.
8. Nhị hợp.
9. Tương hại và tương phá chỉ dùng làm tín hiệu phụ."""

PALACE_FOCUS: Dict[str, str] = {
    "Mệnh": "Khí chất, tư duy, cách quyết định, thích nghi, chịu áp lực, mâu thuẫn nội tâm và điều kiện phát huy.",
    "Phụ Mẫu": "Nền tảng gia đình, hình tượng cha mẹ, cách hỗ trợ, khác biệt quan điểm, mức độ độc lập và ảnh hưởng đến tâm lý/nghề nghiệp/tài chính.",
    "Phúc Đức": "Nền tảng tinh thần, khả năng phục hồi, nếp sống gia đình, mâu thuẫn họ hàng, ảnh hưởng tâm lý dài hạn và cách tạo phúc thực tế.",
    "Điền Trạch": "Cách tạo dựng tài sản, ổn định/thay đổi nơi ở, quản lý nhà đất, liên hệ tài sản–công việc và rủi ro pháp lý/kỹ thuật/tài chính.",
    "Quan Lộc": "Cách làm việc, chuyên môn, quản lý, tham mưu, điều phối, chủ động, lộ trình trách nhiệm và môi trường phù hợp. Không đóng khung nghề nghiệp.",
    "Nô Bộc": "Đồng nghiệp, nhân viên, bạn bè, đối tác, làm việc nhóm, dùng người, tranh quyền/lợi ích, phân quyền và kiểm soát.",
    "Thiên Di": "Hình ảnh xã hội, thích nghi bên ngoài, cơ hội đổi môi trường, quý nhân, rủi ro giao tiếp/di chuyển và điều kiện được công nhận.",
    "Tật Ách": "Khả năng chịu áp lực, thói quen gây mất cân bằng, quan hệ tinh thần–thể chất, phục hồi và điều cần giữ gìn; không chẩn đoán bệnh.",
    "Tài Bạch": "Cách tạo/giữ thu nhập, độ ổn định dòng tiền, kinh doanh/làm thêm/đầu tư, nguồn rủi ro và cách quản trị tài chính.",
    "Tử Tức": "Hai lớp: con cái (tính độc lập, nuôi dạy, quan hệ) và thành quả (sản phẩm, dự án, ý tưởng, học trò, đội ngũ kế thừa). Không đoán số con/sinh sản.",
    "Phu Thê": "Mẫu người và cách tương tác, nhu cầu tình cảm, ảnh hưởng công việc/tài chính/gia đình, điểm mâu thuẫn và điều kiện ổn định; luận trung tính nếu thiếu giới tính.",
    "Huynh Đệ": "Quan hệ anh chị em, hỗ trợ, khác biệt tính cách, tiền bạc/trách nhiệm chung và ảnh hưởng đến gia đình/công việc. Không đoán số lượng.",
}

RELATION_OUTPUT = """ĐẦU RA 6 MỤC
1. Cấu trúc chính: chính tinh, phụ tinh nổi bật, Tứ Hóa, Tuần/Triệt, đối cung và tam hợp quan trọng.
2. Cơ chế vận hành: tư duy, tâm lý, cách hành động và phản ứng trước áp lực/thay đổi.
3. Biểu hiện thực tế: ít nhất 3 khả năng khác nhau, không quy thành một kết quả.
4. Mặt mạnh: năng lực/lợi thế có thể ứng dụng.
5. Điểm yếu và điều kiện phát sinh: rủi ro xuất hiện khi nào, do môi trường/kỹ năng/tâm lý/quan hệ nào kích hoạt.
6. Điều kiện phát huy: môi trường, kỹ năng, cách quản trị và hành động thực tế."""

COMBINED_RULES = """QUY TẮC ĐỐI CHIẾU TỬ VI + BÁT TỰ
- Giữ hai hệ độc lập; ghi rõ dữ kiện nào đến từ Tử Vi, dữ kiện nào đến từ Bát Tự.
- Chỉ gọi là đồng quy khi hai hệ cùng chỉ về một cơ chế/xu hướng tương tự.
- Khi khác nhau, giải thích theo: bản chất–môi trường, năng lực–cách sử dụng, dài hạn–giai đoạn vận, tiềm năng–kết quả thực tế.
- Không cộng điểm sao, Ngũ Hành và Thập Thần thành một chỉ số tuyệt đối.
- Không kết luận Dụng thần nếu dữ liệu/phương pháp chưa đủ.
- Đại vận và lưu niên chỉ dùng cho giai đoạn tương ứng, không thay cho bản chất dài hạn.

Ưu tiên Tử Vi: Mệnh/Thân → Mệnh–Quan–Tài → chính/phụ tinh → Tứ Hóa → Tuần/Triệt → đối cung/tam hợp → vận.
Ưu tiên Bát Tự: Nhật chủ → tháng lệnh theo tiết khí → cường nhược/Ngũ Hành → Thập Thần → quan hệ trụ → Đại vận → lưu niên."""

COMBINED_OUTPUT = """ĐẦU RA 5 MỤC
1. Dữ liệu Tử Vi.
2. Dữ liệu Bát Tự.
3. Điểm đồng quy.
4. Điểm khác biệt hoặc điều kiện hóa.
5. Kết luận ứng dụng: khả năng có xác suất cao, điều kiện phát huy, rủi ro cần quản trị và hành động ưu tiên.

Khi luận nghề nghiệp, chuyển sao/Thập Thần thành nhóm năng lực: phân tích–kỹ thuật; kế hoạch–điều phối; hành chính–hồ sơ; vận hành–sản xuất; chất lượng–kiểm soát; nhân sự; tư vấn–giáo dục; pháp chế–tuân thủ; quản lý dự án/chuyên môn.
Phân loại: Phù hợp cao / Có thể làm tốt nếu có điều kiện / Ít tối ưu nhưng vẫn làm được."""

FULL_OUTPUT = """CẤU TRÚC BÁO CÁO TOÀN BỘ
A. Tổng quan 6–8 ý: năng lực nổi bật, cơ chế tư duy/hành động, điểm nghẽn, trục cung mạnh, Ngũ Hành/Thập Thần nổi bật, môi trường phát huy, rủi ro và xu hướng phát triển.
B. Luận riêng 12 cung: mỗi cung theo 6 mục Cấu trúc chính → Cơ chế → 3 biểu hiện → Mặt mạnh → Rủi ro có điều kiện → Điều kiện phát huy.
C. Các trục liên kết: Mệnh–Quan–Tài; Phúc–Phu–Di; Điền–Tử–Tật; Phụ–Nô–Tử; Quan–Nô; Tài–Tật; Phu–Quan.
D. Đối chiếu Bát Tự: điểm đồng quy, khác biệt, yếu tố thuộc bản chất và yếu tố phụ thuộc môi trường/vận.
E. Kết luận ứng dụng: 3 điểm mạnh, 3 rủi ro, 3 nguyên tắc hành động.

TỰ KIỂM TRA TRƯỚC KHI TRẢ LỜI
- Có gán một sao thành một nghề không?
- Có kết luận quá hẹp/tuyệt đối không?
- Có dùng hại–phá quá mạnh không?
- Có trộn sao lưu niên với sao gốc không?
- Có trộn bản chất với ảnh hưởng của vận không?
Nếu có, phải sửa theo hướng đa khả năng và có điều kiện."""


def _ordered_palaces(chart) -> List[object]:
    names = [
        "Mệnh", "Phụ Mẫu", "Phúc Đức", "Điền Trạch", "Quan Lộc", "Nô Bộc",
        "Thiên Di", "Tật Ách", "Tài Bạch", "Tử Tức", "Phu Thê", "Huynh Đệ",
    ]
    rank = {name.casefold(): index for index, name in enumerate(names)}
    return sorted(chart.palaces, key=lambda p: rank.get(p.palace_name.casefold(), 99))


def _relation_text(relation: Dict[str, object]) -> str:
    lines = [
        f"Cung {relation['palace']} tại {relation['branch']}",
        "Bản cung: " + relation_item_summary(relation["self"]),
        "Đối cung: " + relation_item_summary(relation["opposite"]),
        "Tam hợp: " + " || ".join(relation_item_summary(item) for item in relation["trine"]),
        "Giáp cung: " + " || ".join(relation_item_summary(item) for item in relation["adjacent"]),
        "Nhị hợp: " + relation_item_summary(relation["six_harmony"]),
        "Tương hại: " + relation_item_summary(relation["harm"]),
        "Tương phá: " + relation_item_summary(relation["break"]),
    ]
    return "\n".join(lines)


def chart_context(chart) -> str:
    h = chart.heaven
    b = chart.bazi
    return (
        f"Họ tên: {h.get('name', '—')}\n"
        f"Giới tính: {h.get('gender', '—')}\n"
        f"Dương lịch: {h.get('input_time', '—')}\n"
        f"Âm lịch hiệu dụng: {h.get('chart_lunar_date', '—')}\n"
        f"Năm/tháng/ngày/giờ Can Chi: {h.get('year_can_chi', '—')} | {h.get('month_can_chi', '—')} | "
        f"{h.get('day_can_chi', '—')} | {h.get('hour_can_chi', '—')}\n"
        f"Mệnh–Cục: {h.get('ban_menh', '—')} | {h.get('cuc', '—')} | {h.get('menh_cuc_relation', '—')}\n"
        f"Năm lưu niên: {h.get('annual_year', '—')} ({h.get('annual_year_can_chi', '—')})\n"
        f"Bát Tự: {' | '.join(p.get('text', '—') for p in b.get('pillars', []))}\n"
        f"Nhật chủ: {b.get('day_master', {}).get('stem', '—')} {b.get('day_master', {}).get('element', '—')} | "
        f"Tháng Bát Tự: {b.get('month_method_name', 'Theo tiết khí')}"
    )


def build_relation_prompt(chart, branch_id: int) -> str:
    relation = chart.relations[str(branch_id)]
    palace = str(relation["palace"])
    focus = PALACE_FOCUS.get(palace, "Bám đúng chức năng của cung; không suy diễn ngoài dữ liệu.")
    return "\n\n".join([
        BASE_PROMPT,
        f"NHIỆM VỤ\nPhân tích riêng cung {palace}. Trọng tâm: {focus}",
        RELATION_PRIORITY,
        RELATION_OUTPUT,
        "THÔNG TIN NỀN\n" + chart_context(chart),
        "DỮ LIỆU CUNG ĐÃ ĐƯỢC ENGINE XÁC ĐỊNH\n" + _relation_text(relation),
        "Hãy bắt đầu phân tích theo đúng 6 mục; không lặp lại toàn bộ danh sách sao nếu không cần thiết.",
    ])


def build_all_relations_prompt(chart) -> str:
    blocks = []
    for palace in _ordered_palaces(chart):
        blocks.append(_relation_text(chart.relations[str(palace.branch_id)]))
    return "\n\n".join([
        BASE_PROMPT,
        "NHIỆM VỤ\nLuận toàn bộ 12 cung theo thứ tự ưu tiên và chức năng riêng của từng cung.",
        RELATION_PRIORITY,
        RELATION_OUTPUT,
        FULL_OUTPUT,
        "THÔNG TIN NỀN\n" + chart_context(chart),
        "DỮ LIỆU 12 CUNG ĐÃ ĐƯỢC ENGINE XÁC ĐỊNH\n\n" + "\n\n---\n\n".join(blocks),
        "Hãy bắt đầu từ phần A. Tổng quan, sau đó luận đủ 12 cung và kết thúc bằng tự phản biện.",
    ])


def build_combined_topic_prompt(chart, topic_index: int) -> str:
    topics = chart.combined_analysis.get("topics", [])
    if topic_index < 0 or topic_index >= len(topics):
        raise IndexError("Chủ đề tổng hợp không hợp lệ")
    topic = topics[topic_index]
    return "\n\n".join([
        BASE_PROMPT,
        f"NHIỆM VỤ\nĐối chiếu chủ đề: {topic['topic']}.",
        COMBINED_RULES,
        COMBINED_OUTPUT,
        "THÔNG TIN NỀN\n" + chart_context(chart),
        "DỮ LIỆU ĐÃ ĐƯỢC ENGINE XÁC ĐỊNH\n" + combined_topic_text(topic),
        "TÍN HIỆU GIAO THOA\n" + cross_system_signal_text(chart.combined_analysis.get("cross_system_signals", [])),
        "Hãy trả lời đúng 5 mục; nêu rõ dữ kiện, suy luận và điều kiện.",
    ])




def _full_bazi_text(chart) -> str:
    """Stable, human-readable dump of all Bát Tự data sent to Gemini."""
    b = chart.bazi
    lines = [
        "BÁT TỰ ĐẦY ĐỦ",
        "=" * 92,
        f"Thời điểm dương lịch: {b.get('birth_solar_datetime', '—')}",
        f"Ngày hiệu dụng: {b.get('effective_day_date', '—')}",
        f"Âm lịch hiệu dụng: {b.get('effective_lunar_date', '—')}",
        f"Năm Bát Tự: {b.get('bazi_year', '—')}",
        f"Cách xác định tháng: {b.get('month_method_name', '—')} | {b.get('month_basis_label', '—')}",
        f"Tiết khí tháng: {b.get('month_jie', '—')}",
        "",
        "TỨ TRỤ",
    ]
    for pillar in b.get("pillars", []) or []:
        hidden = ", ".join(
            f"{item.get('stem', '—')} ({item.get('ten_god', '—')}, {item.get('element', '—')})"
            for item in (pillar.get("hidden_stems", []) or [])
        ) or "—"
        lines.append(
            f"- Trụ {pillar.get('label', '—')}: {pillar.get('text', '—')} | "
            f"{pillar.get('yin_yang', '—')} | Can {pillar.get('stem_element', '—')} | "
            f"Chi {pillar.get('branch_element', '—')} | Thập thần {pillar.get('ten_god', '—')} | "
            f"Nạp âm {pillar.get('nap_am', '—')} | Tàng can: {hidden}"
        )
    dm = b.get("day_master", {}) or {}
    lines.extend([
        "",
        "NHẬT CHỦ",
        f"{dm.get('stem', '—')} — {dm.get('yin_yang', '—')} {dm.get('element', '—')} | "
        f"Cường nhược sơ bộ: {dm.get('preliminary_strength', '—')} | "
        f"Trợ thân: {dm.get('support_ratio_percent', '—')}% | "
        f"Hành cân bằng sơ bộ: {', '.join(dm.get('balancing_elements_preliminary', []) or []) or '—'}",
        f"Lưu ý: {dm.get('warning', '—')}",
        "",
        "PHÂN BỐ NGŨ HÀNH",
    ])
    balance = b.get("element_balance", {}) or {}
    percentages = balance.get("percentages", {}) or {}
    lines.append(" | ".join(f"{name}: {value}%" for name, value in percentages.items()) or "—")
    lines.append(f"Hành trội: {balance.get('dominant', '—')} | Hành yếu: {balance.get('weakest', '—')}")
    lines.extend(["", "PHÂN BỐ THẬP THẦN"])
    distribution = b.get("ten_god_distribution", {}) or {}
    lines.extend(f"- {name}: {value}" for name, value in distribution.items())
    luck = b.get("luck_cycles", {}) or {}
    lines.extend([
        "",
        "ĐẠI VẬN",
        f"Chiều: {luck.get('direction', '—')} | Khởi vận: {luck.get('start_age_text', '—')} | "
        f"Căn cứ: {luck.get('method', '—')}",
    ])
    for cycle in luck.get("cycles", []) or []:
        lines.append(
            f"- {cycle.get('label', '—')}: {cycle.get('text', '—')} | "
            f"{cycle.get('start_age', '—')}–{cycle.get('end_age', '—')} tuổi | "
            f"Thập thần {cycle.get('ten_god', '—')} | Nạp âm {cycle.get('nap_am', '—')}"
        )
    conventions = b.get("conventions", {}) or {}
    if conventions:
        lines.extend(["", "QUY ƯỚC BÁT TỰ"] + [f"- {key}: {value}" for key, value in conventions.items()])
    return "\n".join(lines)

def build_full_report_prompt(chart) -> str:
    return "\n\n".join([
        BASE_PROMPT,
        "NHIỆM VỤ\nPhân tích toàn bộ lá số Tử Vi và Bát Tự, ưu tiên giá trị ứng dụng.",
        RELATION_PRIORITY,
        COMBINED_RULES,
        FULL_OUTPUT,
        "THÔNG TIN NỀN\n" + chart_context(chart),
        "DỮ LIỆU ĐỐI CHIẾU TỬ VI + BÁT TỰ ĐÃ ĐƯỢC ENGINE XÁC ĐỊNH\n" + all_combined_text(chart.combined_analysis),
        _full_bazi_text(chart),
        "DỮ LIỆU TỬ VI ĐẦY ĐỦ 12 CUNG\n" + "\n\n---\n\n".join(
            _relation_text(chart.relations[str(palace.branch_id)]) for palace in _ordered_palaces(chart)
        ),
        "Hãy xuất báo cáo A–E, sau đó tự kiểm tra và chỉ đưa ra phiên bản đã sửa.",
    ])



AUTO_REPORT_PARTS = [
    {
        "title": "PHẦN 1/4 — TỔNG QUAN, MỆNH, PHỤ MẪU, PHÚC ĐỨC",
        "palaces": ["Mệnh", "Phụ Mẫu", "Phúc Đức"],
        "instructions": """Viết phần mở đầu tổng quan 8–12 ý, sau đó luận lần lượt Mệnh, Phụ Mẫu và Phúc Đức. Mỗi cung bắt buộc đủ 6 mục: Cấu trúc chính; Cơ chế vận hành; ít nhất 3 biểu hiện thực tế; Mặt mạnh; Điểm yếu/rủi ro có điều kiện; Điều kiện phát huy. Tổng độ dài mục tiêu 1.500–2.200 từ, không được rút thành vài đoạn ngắn.""",
    },
    {
        "title": "PHẦN 2/4 — ĐIỀN TRẠCH, QUAN LỘC, NÔ BỘC",
        "palaces": ["Điền Trạch", "Quan Lộc", "Nô Bộc"],
        "instructions": """Luận sâu Điền Trạch, Quan Lộc và Nô Bộc. Riêng Quan Lộc phải phân tích cách làm việc, chuyên môn, quản lý, tham mưu, điều phối, mức chủ động, môi trường phù hợp và nhiều nhóm nghề theo năng lực; không đóng khung một nghề. Mỗi cung đủ 6 mục và có ví dụ thực tế. Tổng độ dài mục tiêu 1.400–2.000 từ.""",
    },
    {
        "title": "PHẦN 3/4 — THIÊN DI, TẬT ÁCH, TÀI BẠCH",
        "palaces": ["Thiên Di", "Tật Ách", "Tài Bạch"],
        "instructions": """Luận sâu Thiên Di, Tật Ách và Tài Bạch. Tật Ách chỉ phân tích áp lực, thói quen mất cân bằng, liên hệ tinh thần–thể chất và khả năng phục hồi; không chẩn đoán bệnh. Tài Bạch phải phân tích tạo thu nhập, giữ tiền, dòng tiền, kinh doanh/đầu tư và cách quản trị rủi ro. Mỗi cung đủ 6 mục, có ít nhất 3 biểu hiện thực tế. Tổng độ dài mục tiêu 1.400–2.000 từ.""",
    },
    {
        "title": "PHẦN 4/4 — TỬ TỨC, PHU THÊ, HUYNH ĐỆ, BÁT TỰ VÀ KẾT LUẬN",
        "palaces": ["Tử Tức", "Phu Thê", "Huynh Đệ"],
        "instructions": """Luận đủ Tử Tức, Phu Thê và Huynh Đệ theo 6 mục. Sau đó đối chiếu toàn bộ Bát Tự với Tử Vi; phân tích các trục Mệnh–Quan–Tài, Phúc–Phu–Di, Điền–Tử–Tật, Phụ–Nô–Tử, Quan–Nô, Tài–Tật và Phu–Quan. Kết thúc bằng 3 điểm mạnh, 3 rủi ro, 3 nguyên tắc hành động và phần tự phản biện. Tổng độ dài mục tiêu 1.800–2.600 từ.""",
    },
]


def build_auto_report_part_prompt(chart, part_index: int) -> str:
    """Build one long-form section of the automatic Gemini report.

    Splitting the report into four calls avoids a short or truncated answer while
    preserving deterministic chart data and the same interpretation rules.
    """
    if part_index < 0 or part_index >= len(AUTO_REPORT_PARTS):
        raise IndexError("Phần báo cáo tự động không hợp lệ")
    config = AUTO_REPORT_PARTS[part_index]
    wanted = set(config["palaces"])
    blocks = [
        _relation_text(chart.relations[str(palace.branch_id)])
        for palace in _ordered_palaces(chart)
        if palace.palace_name in wanted
    ]
    sections = [
        BASE_PROMPT,
        f"NHIỆM VỤ\n{config['title']}",
        RELATION_PRIORITY,
        config["instructions"],
        "YÊU CẦU ĐỘ SÂU\n- Không tóm tắt qua loa.\n- Mỗi nhận định phải nêu dữ kiện, cơ chế, điều kiện và ví dụ ứng dụng.\n- Không lặp lại nguyên danh sách sao; phải giải thích ý nghĩa tổng hợp.\n- Dùng tiêu đề Markdown rõ ràng để ghép bốn phần thành một báo cáo thống nhất.",
        "THÔNG TIN NỀN\n" + chart_context(chart),
        "DỮ LIỆU CÁC CUNG TRONG PHẦN NÀY\n\n" + "\n\n---\n\n".join(blocks),
    ]
    if part_index == 0:
        sections.append("DỮ LIỆU ĐỐI CHIẾU TỔNG QUAN TỬ VI + BÁT TỰ\n" + all_combined_text(chart.combined_analysis))
    if part_index == len(AUTO_REPORT_PARTS) - 1:
        sections.extend([
            COMBINED_RULES,
            "DỮ LIỆU ĐỐI CHIẾU TỬ VI + BÁT TỰ\n" + all_combined_text(chart.combined_analysis),
            _full_bazi_text(chart),
            "KẾT THÚC BẮT BUỘC\n- 3 điểm mạnh nên phát huy.\n- 3 rủi ro cần kiểm soát.\n- 3 nguyên tắc hành động thực tế.\n- Tự phản biện các kết luận quá hẹp, tuyệt đối hoặc trộn lưu niên với bản mệnh.",
        ])
    sections.append("Chỉ viết đúng phần được giao; không bỏ sót cung và không kết thúc sớm.")
    return "\n\n".join(sections)

def prompt_profile_metadata() -> Dict[str, object]:
    return {
        "version": PROMPT_PROFILE_VERSION,
        "style": "thực tế, phản biện, đa khả năng, có điều kiện",
        "available_prompts": [
            "Quan hệ một cung",
            "Quan hệ đủ 12 cung",
            "Tổng hợp một chủ đề Tử Vi + Bát Tự",
            "Báo cáo toàn bộ Tử Vi + Bát Tự",
            "Báo cáo tự động dài 4 phần",
        ],
        "safety": [
            "không kết luận tuyệt đối",
            "không chẩn đoán bệnh",
            "không trộn sao lưu niên với sao gốc",
            "không tự thêm dữ kiện",
        ],
    }
