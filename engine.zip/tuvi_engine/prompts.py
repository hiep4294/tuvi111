# -*- coding: utf-8 -*-
"""Prompt profiles for AI-assisted Tử Vi and Bát Tự interpretation.

The prompts deliberately separate deterministic chart facts from narrative
interpretation. They are editable/copyable in the desktop UI; no AI call is
performed by this module.
"""
from __future__ import annotations

from typing import Dict, Iterable, List

from tuvi_engine.combined_presentation import (
    all_combined_text,
    combined_topic_text,
    cross_system_signal_text,
    relation_item_summary,
)

PROMPT_PROFILE_VERSION = "practical-clear-v1.15-sequential"

BASE_PROMPT = """Bạn là chuyên gia phân tích Tử Vi và Bát Tự theo hướng thực tế, rõ ràng và có tư duy phản biện.

NGUYÊN TẮC BẮT BUỘC
- Chỉ dùng dữ liệu được cung cấp; không tự thêm sao, cung, Can Chi, Tứ Hóa hoặc quan hệ.
- Không biến một sao hay một tổ hợp thành một nghề, tính cách hoặc sự kiện duy nhất.
- Không kết luận tuyệt đối về giàu nghèo, hôn nhân, sức khỏe, con cái hoặc nghề nghiệp.
- Mỗi nhận định phải có nhiều khả năng và nêu điều kiện khiến mặt tốt hoặc mặt bất lợi xuất hiện.
- Sao có tiền tố “L.” chỉ dùng cho năm đang xem, không dùng để kết luận lâu dài.
- Tuần và Triệt phải nêu cả hai mặt: làm chậm, gây gián đoạn; đồng thời giảm cực đoan và tạo sàng lọc.
- Nhị hợp, tương hại và tương phá chỉ là tín hiệu phụ, không được lấn át bản cung.
- Không chẩn đoán bệnh. Không thay thế quyết định y tế, tài chính, pháp lý hoặc nghề nghiệp.

CÁCH VIẾT
- Dùng tiếng Việt phổ thông, câu ngắn, dễ hiểu.
- Không dùng từ tiếng Anh hoặc đặt thêm tên tiếng Anh trong ngoặc.
- Hạn chế thuật ngữ chuyên môn. Nếu bắt buộc dùng, giải thích ngắn ngay lần đầu.
- Không dùng sơ đồ ký tự, không dựng bảng dài, không lặp lại toàn bộ danh sách sao.
- Chỉ dùng các mục đã quy định; không thêm phần kiểm chứng riêng hoặc phần hướng dẫn hành động riêng.
- Không dùng giọng áp đặt, dọa nạt hoặc tâng bốc.
- Ưu tiên kết luận cân bằng, ngắn gọn và dễ đọc."""

RELATION_PRIORITY = """THỨ TỰ XEM XÉT
1. Bản cung và chính tinh.
2. Phụ tinh tại bản cung.
3. Tứ Hóa gốc.
4. Tuần/Triệt.
5. Đối cung.
6. Hai cung tam hợp.
7. Giáp cung.
8. Nhị hợp.
9. Tương hại và tương phá chỉ dùng bổ sung."""

PALACE_FOCUS: Dict[str, str] = {
    "Mệnh": "Khí chất, tư duy, cách quyết định, thích nghi và phản ứng khi chịu áp lực.",
    "Phụ Mẫu": "Nền tảng gia đình, cách cha mẹ hỗ trợ, khác biệt quan điểm và mức độ độc lập.",
    "Phúc Đức": "Nền tảng tinh thần, khả năng phục hồi, nếp sống gia đình và ảnh hưởng lâu dài.",
    "Điền Trạch": "Cách tạo dựng, giữ gìn tài sản và xu hướng ổn định hoặc thay đổi nơi ở.",
    "Quan Lộc": "Cách làm việc, năng lực chuyên môn, quản lý, phối hợp và môi trường phù hợp. Không đóng khung một nghề.",
    "Nô Bộc": "Bạn bè, đồng nghiệp, nhân viên, đối tác, khả năng làm việc nhóm và ranh giới lợi ích.",
    "Thiên Di": "Khả năng thích nghi khi ra ngoài, hình ảnh xã hội, cơ hội và rủi ro khi đổi môi trường.",
    "Tật Ách": "Khả năng chịu áp lực, thói quen gây mất cân bằng và khả năng phục hồi; không chẩn đoán bệnh.",
    "Tài Bạch": "Cách tạo thu nhập, giữ tiền, mức ổn định dòng tiền và rủi ro trong quyết định tài chính.",
    "Tử Tức": "Hai lớp: con cái và thành quả như dự án, sản phẩm, học trò hoặc đội ngũ kế thừa.",
    "Phu Thê": "Mẫu tương tác, nhu cầu tình cảm, điểm dễ mâu thuẫn và điều kiện để quan hệ ổn định.",
    "Huynh Đệ": "Mức độ hỗ trợ, khác biệt tính cách, tiền bạc và trách nhiệm chung giữa anh chị em.",
}

RELATION_OUTPUT = """CẤU TRÚC MỖI CUNG
1. Cơ chế vận hành: giải thích ngắn cách cung này tác động đến suy nghĩ, phản ứng hoặc cách xử lý vấn đề.
2. Biểu hiện thực tế: nêu 2–3 khả năng dễ gặp, viết ngắn và không khẳng định một kết quả duy nhất.
3. Mặt mạnh: nêu lợi thế hoặc năng lực có thể phát huy.
4. Điểm yếu/Rủi ro có điều kiện: nêu mặt bất lợi và điều kiện khiến nó xuất hiện.

Mỗi cung khoảng 70–110 từ. Chỉ dùng đúng bốn mục trên, không thêm mục phụ, không lặp lại toàn bộ danh sách sao."""

COMBINED_RULES = """QUY TẮC KẾT HỢP TỬ VI VÀ BÁT TỰ
- Giữ hai hệ riêng, sau đó chỉ ra chỗ giống nhau và chỗ khác nhau.
- Khi hai hệ khác nhau, giải thích theo hoàn cảnh, cách sử dụng năng lực hoặc từng giai đoạn; không chọn tùy ý một bên.
- Không cộng các sao và Ngũ Hành thành một điểm số tuyệt đối.
- Đại vận và lưu niên chỉ dùng cho giai đoạn tương ứng, không thay cho đặc điểm lâu dài.
- Với Bát Tự, dùng từ dễ hiểu. Ví dụ: thay “cường vượng” bằng “năng lượng mạnh”, thay “Kiếp Tài” bằng “tính cạnh tranh hoặc xu hướng chia sẻ nguồn lực” khi cần diễn giải."""

COMBINED_OUTPUT = """CÁCH TRÌNH BÀY PHẦN KẾT HỢP
1. Tử Vi cho thấy gì.
2. Bát Tự cho thấy gì.
3. Hai hệ cùng nhấn mạnh điểm nào.
4. Điểm khác nhau và điều kiện làm mỗi biểu hiện xuất hiện.

Không tạo mục riêng về mức độ tin cậy hoặc cách ứng dụng."""

FULL_OUTPUT = """TRÌNH TỰ BÁO CÁO
1. Tổng quan lá số.
2. Luận lần lượt 12 cung theo thứ tự: Mệnh, Phụ Mẫu, Phúc Đức, Điền Trạch, Quan Lộc, Nô Bộc, Thiên Di, Tật Ách, Tài Bạch, Tử Tức, Phu Thê, Huynh Đệ.
3. Bát Tự.
4. Kết luận chung.

Mỗi cung chỉ dùng bốn mục: Cơ chế vận hành; Biểu hiện thực tế; Mặt mạnh; Điểm yếu/Rủi ro có điều kiện. Tổng báo cáo nên ngắn gọn, dễ hiểu và không áp đặt."""


def _ordered_palaces(chart) -> List[object]:
    names = [
        "Mệnh", "Phụ Mẫu", "Phúc Đức", "Điền Trạch", "Quan Lộc", "Nô Bộc",
        "Thiên Di", "Tật Ách", "Tài Bạch", "Tử Tức", "Phu Thê", "Huynh Đệ",
    ]
    rank = {name.casefold(): index for index, name in enumerate(names)}
    return sorted(chart.palaces, key=lambda p: rank.get(p.palace_name.casefold(), 99))


def _relation_text(relation: Dict[str, object]) -> str:
    lines = [
        f"Cung {relation['palace']} tại {relation['branch']}",
        "Bản cung: " + relation_item_summary(relation["self"]),
        "Đối cung: " + relation_item_summary(relation["opposite"]),
        "Tam hợp: " + " || ".join(relation_item_summary(item) for item in relation["trine"]),
        "Giáp cung: " + " || ".join(relation_item_summary(item) for item in relation["adjacent"]),
        "Nhị hợp: " + relation_item_summary(relation["six_harmony"]),
        "Tương hại: " + relation_item_summary(relation["harm"]),
        "Tương phá: " + relation_item_summary(relation["break"]),
    ]
    return "\n".join(lines)


def chart_context(chart) -> str:
    h = chart.heaven
    b = chart.bazi
    return (
        f"Họ tên: {h.get('name', '—')}\n"
        f"Giới tính: {h.get('gender', '—')}\n"
        f"Dương lịch: {h.get('input_time', '—')}\n"
        f"Âm lịch hiệu dụng: {h.get('chart_lunar_date', '—')}\n"
        f"Năm/tháng/ngày/giờ Can Chi: {h.get('year_can_chi', '—')} | {h.get('month_can_chi', '—')} | "
        f"{h.get('day_can_chi', '—')} | {h.get('hour_can_chi', '—')}\n"
        f"Mệnh–Cục: {h.get('ban_menh', '—')} | {h.get('cuc', '—')} | {h.get('menh_cuc_relation', '—')}\n"
        f"Năm lưu niên: {h.get('annual_year', '—')} ({h.get('annual_year_can_chi', '—')})\n"
        f"Bát Tự: {' | '.join(p.get('text', '—') for p in b.get('pillars', []))}\n"
        f"Nhật chủ: {b.get('day_master', {}).get('stem', '—')} {b.get('day_master', {}).get('element', '—')} | "
        f"Tháng Bát Tự: {b.get('month_method_name', 'Theo tiết khí')}"
    )


def build_relation_prompt(chart, branch_id: int) -> str:
    relation = chart.relations[str(branch_id)]
    palace = str(relation["palace"])
    focus = PALACE_FOCUS.get(palace, "Bám đúng chức năng của cung; không suy diễn ngoài dữ liệu.")
    return "\n\n".join([
        BASE_PROMPT,
        f"NHIỆM VỤ\nPhân tích riêng cung {palace}. Trọng tâm: {focus}",
        RELATION_PRIORITY,
        RELATION_OUTPUT,
        "THÔNG TIN NỀN\n" + chart_context(chart),
        "DỮ LIỆU CUNG ĐÃ ĐƯỢC ENGINE XÁC ĐỊNH\n" + _relation_text(relation),
        "Hãy viết đúng 4 mục, ngắn gọn và không lặp lại toàn bộ danh sách sao.",
    ])


def build_all_relations_prompt(chart) -> str:
    blocks = []
    for palace in _ordered_palaces(chart):
        blocks.append(_relation_text(chart.relations[str(palace.branch_id)]))
    return "\n\n".join([
        BASE_PROMPT,
        "NHIỆM VỤ\nLuận toàn bộ 12 cung theo thứ tự ưu tiên và chức năng riêng của từng cung.",
        RELATION_PRIORITY,
        RELATION_OUTPUT,
        FULL_OUTPUT,
        "THÔNG TIN NỀN\n" + chart_context(chart),
        "DỮ LIỆU 12 CUNG ĐÃ ĐƯỢC ENGINE XÁC ĐỊNH\n\n" + "\n\n---\n\n".join(blocks),
        "Hãy viết theo thứ tự: tổng quan, 12 cung, Bát Tự, kết luận. Mỗi cung chỉ dùng đúng bốn mục đã quy định.",
    ])


def build_combined_topic_prompt(chart, topic_index: int) -> str:
    topics = chart.combined_analysis.get("topics", [])
    if topic_index < 0 or topic_index >= len(topics):
        raise IndexError("Chủ đề tổng hợp không hợp lệ")
    topic = topics[topic_index]
    return "\n\n".join([
        BASE_PROMPT,
        f"NHIỆM VỤ\nĐối chiếu chủ đề: {topic['topic']}.",
        COMBINED_RULES,
        COMBINED_OUTPUT,
        "THÔNG TIN NỀN\n" + chart_context(chart),
        "DỮ LIỆU ĐÃ ĐƯỢC ENGINE XÁC ĐỊNH\n" + combined_topic_text(topic),
        "TÍN HIỆU GIAO THOA\n" + cross_system_signal_text(chart.combined_analysis.get("cross_system_signals", [])),
        "Hãy trả lời đúng 4 mục, dùng từ phổ thông và tránh kết luận một chiều.",
    ])




def _full_bazi_text(chart) -> str:
    """Stable, human-readable dump of all Bát Tự data sent to Gemini."""
    b = chart.bazi
    lines = [
        "BÁT TỰ ĐẦY ĐỦ",
        "=" * 92,
        f"Thời điểm dương lịch: {b.get('birth_solar_datetime', '—')}",
        f"Ngày hiệu dụng: {b.get('effective_day_date', '—')}",
        f"Âm lịch hiệu dụng: {b.get('effective_lunar_date', '—')}",
        f"Năm Bát Tự: {b.get('bazi_year', '—')}",
        f"Cách xác định tháng: {b.get('month_method_name', '—')} | {b.get('month_basis_label', '—')}",
        f"Tiết khí tháng: {b.get('month_jie', '—')}",
        "",
        "TỨ TRỤ",
    ]
    for pillar in b.get("pillars", []) or []:
        hidden = ", ".join(
            f"{item.get('stem', '—')} ({item.get('ten_god', '—')}, {item.get('element', '—')})"
            for item in (pillar.get("hidden_stems", []) or [])
        ) or "—"
        lines.append(
            f"- Trụ {pillar.get('label', '—')}: {pillar.get('text', '—')} | "
            f"{pillar.get('yin_yang', '—')} | Can {pillar.get('stem_element', '—')} | "
            f"Chi {pillar.get('branch_element', '—')} | Thập thần {pillar.get('ten_god', '—')} | "
            f"Nạp âm {pillar.get('nap_am', '—')} | Tàng can: {hidden}"
        )
    dm = b.get("day_master", {}) or {}
    lines.extend([
        "",
        "NHẬT CHỦ",
        f"{dm.get('stem', '—')} — {dm.get('yin_yang', '—')} {dm.get('element', '—')} | "
        f"Cường nhược sơ bộ: {dm.get('preliminary_strength', '—')} | "
        f"Trợ thân: {dm.get('support_ratio_percent', '—')}% | "
        f"Hành cân bằng sơ bộ: {', '.join(dm.get('balancing_elements_preliminary', []) or []) or '—'}",
        f"Lưu ý: {dm.get('warning', '—')}",
        "",
        "PHÂN BỐ NGŨ HÀNH",
    ])
    balance = b.get("element_balance", {}) or {}
    percentages = balance.get("percentages", {}) or {}
    lines.append(" | ".join(f"{name}: {value}%" for name, value in percentages.items()) or "—")
    lines.append(f"Hành trội: {balance.get('dominant', '—')} | Hành yếu: {balance.get('weakest', '—')}")
    lines.extend(["", "PHÂN BỐ THẬP THẦN"])
    distribution = b.get("ten_god_distribution", {}) or {}
    lines.extend(f"- {name}: {value}" for name, value in distribution.items())
    luck = b.get("luck_cycles", {}) or {}
    lines.extend([
        "",
        "ĐẠI VẬN",
        f"Chiều: {luck.get('direction', '—')} | Khởi vận: {luck.get('start_age_text', '—')} | "
        f"Căn cứ: {luck.get('method', '—')}",
    ])
    for cycle in luck.get("cycles", []) or []:
        lines.append(
            f"- {cycle.get('label', '—')}: {cycle.get('text', '—')} | "
            f"{cycle.get('start_age', '—')}–{cycle.get('end_age', '—')} tuổi | "
            f"Thập thần {cycle.get('ten_god', '—')} | Nạp âm {cycle.get('nap_am', '—')}"
        )
    conventions = b.get("conventions", {}) or {}
    if conventions:
        lines.extend(["", "QUY ƯỚC BÁT TỰ"] + [f"- {key}: {value}" for key, value in conventions.items()])
    return "\n".join(lines)

def build_full_report_prompt(chart) -> str:
    return "\n\n".join([
        BASE_PROMPT,
        "NHIỆM VỤ\nPhân tích toàn bộ lá số Tử Vi và Bát Tự, ưu tiên giá trị ứng dụng.",
        RELATION_PRIORITY,
        COMBINED_RULES,
        FULL_OUTPUT,
        "THÔNG TIN NỀN\n" + chart_context(chart),
        "DỮ LIỆU ĐỐI CHIẾU TỬ VI + BÁT TỰ ĐÃ ĐƯỢC ENGINE XÁC ĐỊNH\n" + all_combined_text(chart.combined_analysis),
        _full_bazi_text(chart),
        "DỮ LIỆU TỬ VI ĐẦY ĐỦ 12 CUNG\n" + "\n\n---\n\n".join(
            _relation_text(chart.relations[str(palace.branch_id)]) for palace in _ordered_palaces(chart)
        ),
        "Hãy viết theo thứ tự: tổng quan lá số, lần lượt 12 cung, Bát Tự, kết luận chung. Không thêm các mục ngoài yêu cầu.",
    ])



AUTO_REPORT_PARTS = [
    {
        "kind": "overview",
        "title": "TỔNG QUAN LÁ SỐ",
        "instructions": """Viết 5–7 ý ngắn, tổng cộng khoảng 250–350 từ. Nêu khí chất chung, cách suy nghĩ, điểm mạnh nổi bật, điểm dễ vướng và xu hướng phát triển. Không luận chi tiết từng cung ở bước này. Không dùng bảng, sơ đồ hoặc lời mở đầu dài.""",
    },
    *[
        {
            "kind": "palace",
            "title": f"CUNG {name.upper()}",
            "palace": name,
            "instructions": """Chỉ luận đúng cung được giao. Dùng đúng bốn mục: Cơ chế vận hành; Biểu hiện thực tế; Mặt mạnh; Điểm yếu/Rủi ro có điều kiện. Mỗi cung khoảng 70–110 từ. Biểu hiện thực tế chỉ cần 2–3 ý ngắn. Không thêm mục khác.""",
        }
        for name in [
            "Mệnh", "Phụ Mẫu", "Phúc Đức", "Điền Trạch", "Quan Lộc", "Nô Bộc",
            "Thiên Di", "Tật Ách", "Tài Bạch", "Tử Tức", "Phu Thê", "Huynh Đệ",
        ]
    ],
    {
        "kind": "bazi",
        "title": "BÁT TỰ",
        "instructions": """Tóm tắt Bát Tự trong khoảng 250–350 từ. Dùng tiếng Việt phổ thông. Nêu Nhật chủ, sự cân bằng Ngũ Hành, cách phản ứng, điểm mạnh, điểm dễ mất cân bằng và các giai đoạn vận chính. Không lặp lại toàn bộ Can Chi hoặc thuật ngữ khó hiểu.""",
    },
    {
        "kind": "conclusion",
        "title": "KẾT LUẬN CHUNG",
        "instructions": """Viết 5–7 ý kết luận, khoảng 250–350 từ. Tổng hợp điểm nổi bật của Tử Vi và Bát Tự, nêu mặt thuận và rủi ro có điều kiện. Không ra lệnh, không áp đặt, không nhắc lại toàn bộ từng cung, không tạo mục về mức độ tin cậy hoặc cách ứng dụng.""",
    },
]


def build_auto_report_part_prompt(chart, part_index: int) -> str:
    """Build one sequential Gemini step: overview, 12 palaces, Bát Tự, conclusion."""
    if part_index < 0 or part_index >= len(AUTO_REPORT_PARTS):
        raise IndexError("Bước báo cáo tự động không hợp lệ")
    config = AUTO_REPORT_PARTS[part_index]
    kind = config["kind"]
    sections = [
        BASE_PROMPT,
        f"NHIỆM VỤ\nBƯỚC {part_index + 1}/{len(AUTO_REPORT_PARTS)} — {config['title']}",
        config["instructions"],
        "THÔNG TIN NỀN\n" + chart_context(chart),
    ]

    if kind == "overview":
        sections.extend([
            COMBINED_RULES,
            "DỮ LIỆU TỔNG QUAN ĐÃ ĐƯỢC ENGINE XÁC ĐỊNH\n" + all_combined_text(chart.combined_analysis),
            "Không đi sâu từng cung trong bước này.",
        ])
    elif kind == "palace":
        palace_name = config["palace"]
        palace = next(p for p in _ordered_palaces(chart) if p.palace_name.casefold() == palace_name.casefold())
        sections.extend([
            RELATION_PRIORITY,
            RELATION_OUTPUT,
            f"TRỌNG TÂM CUNG {palace_name.upper()}\n{PALACE_FOCUS.get(palace_name, '')}",
            "DỮ LIỆU CUNG ĐÃ ĐƯỢC ENGINE XÁC ĐỊNH\n" + _relation_text(chart.relations[str(palace.branch_id)]),
        ])
    elif kind == "bazi":
        sections.extend([
            COMBINED_RULES,
            _full_bazi_text(chart),
            "Chỉ tóm tắt Bát Tự ở bước này; không luận lại 12 cung.",
        ])
    elif kind == "conclusion":
        sections.extend([
            COMBINED_RULES,
            "DỮ LIỆU TỔNG HỢP TỬ VI VÀ BÁT TỰ\n" + all_combined_text(chart.combined_analysis),
            "TÓM TẮT BÁT TỰ\n" + chart_context(chart),
            "Chỉ kết luận chung; không chép lại từng cung.",
        ])

    sections.append("Dùng câu ngắn, từ phổ thông và chỉ viết đúng bước được giao.")
    return "\n\n".join(sections)


def prompt_profile_metadata() -> Dict[str, object]:
    return {
        "version": PROMPT_PROFILE_VERSION,
        "style": "ngắn gọn, dễ hiểu, cân bằng, có điều kiện",
        "available_prompts": [
            "Quan hệ một cung",
            "Quan hệ đủ 12 cung",
            "Tổng hợp một chủ đề Tử Vi + Bát Tự",
            "Báo cáo toàn bộ Tử Vi + Bát Tự",
            "Báo cáo tự động 15 bước: tổng quan, 12 cung, Bát Tự, kết luận",
        ],
        "safety": [
            "không kết luận tuyệt đối",
            "không chẩn đoán bệnh",
            "không trộn sao lưu niên với sao gốc",
            "không tự thêm dữ kiện",
        ],
    }
