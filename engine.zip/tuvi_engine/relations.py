# -*- coding: utf-8 -*-
from typing import Dict, List

from tuvi_engine.legacy.AmDuong import dichCung
from tuvi_engine.presentation import split_palace_stars, star_element_code


SIX_HARMONY = {1: 2, 2: 1, 3: 12, 12: 3, 4: 11, 11: 4,
               5: 10, 10: 5, 6: 9, 9: 6, 7: 8, 8: 7}
HARM = {1: 8, 8: 1, 2: 7, 7: 2, 3: 6, 6: 3,
        4: 5, 5: 4, 9: 12, 12: 9, 10: 11, 11: 10}
BREAK = {1: 10, 10: 1, 2: 5, 5: 2, 3: 12, 12: 3,
         4: 7, 7: 4, 6: 9, 9: 6, 8: 11, 11: 8}


def build_relations(palaces: List[dict]) -> Dict[str, dict]:
    """Precompute palace relations so an AI never has to infer geometry."""
    by_branch = {p["branch_id"]: p for p in palaces}
    result = {}
    for branch, palace in by_branch.items():
        opposite = dichCung(branch, 6)
        adjacent = [dichCung(branch, -1), dichCung(branch, 1)]
        trine = [dichCung(branch, 4), dichCung(branch, 8)]
        relation = {
            "palace": palace["palace_name"],
            "branch": palace["branch_name"],
            "self": _brief(palace),
            "opposite": _brief(by_branch[opposite]),
            "adjacent": [_brief(by_branch[i]) for i in adjacent],
            "trine": [_brief(by_branch[i]) for i in trine],
            "six_harmony": _brief(by_branch[SIX_HARMONY[branch]]),
            "harm": _brief(by_branch[HARM[branch]]),
            "break": _brief(by_branch[BREAK[branch]]),
        }
        result[str(branch)] = relation
    return result


def _names(stars):
    return [s.get("saoTen", "") for s in stars if s.get("saoTen")]


def _star_detail(star: dict) -> dict:
    name = star.get("saoTen", "")
    element_name = star.get("element_name", "Chưa xác định")
    return {
        "star_id": star.get("saoID"),
        "name": name,
        "element_code": star_element_code(star),
        "element_name": element_name,
        "element_color": star.get("element_color", "#333333"),
        "nature": star.get("nature", "neutral"),
        "label": f"{name} ({element_name})" if name else "",
    }


def _details(stars):
    return [_star_detail(star) for star in stars if star.get("saoTen")]


def _brief(palace: dict) -> dict:
    groups = split_palace_stars(palace["stars"])
    main = groups["main"]
    good = groups["good"] + groups["neutral"]
    bad = groups["bad"]
    transformations = [
        star for star in palace["stars"] if star.get("saoID") in (92, 93, 94, 95)
    ]
    trang_sinh = groups["trang_sinh"]
    annual_stars = palace.get("annual_stars", []) or []
    annual_good = [s for s in annual_stars if s.get("nature") == "good"]
    annual_bad = [s for s in annual_stars if s.get("nature") == "bad"]
    annual_neutral = [s for s in annual_stars if s.get("nature") not in {"good", "bad"}]
    return {
        "branch_id": palace["branch_id"],
        "branch": palace["branch_name"],
        "palace": palace["palace_name"],
        # Trường cũ giữ nguyên để tương thích API.
        "major_stars": _names(main),
        "good_stars": _names(good),
        "bad_stars": _names(bad),
        "transformations": _names(transformations),
        "trang_sinh": trang_sinh.get("saoTen") if trang_sinh else None,
        # Trường mới dùng cho UI, HTML, AI và server.
        "major_star_details": _details(main),
        "good_star_details": _details(good),
        "bad_star_details": _details(bad),
        "transformation_details": _details(transformations),
        "trang_sinh_detail": _star_detail(trang_sinh) if trang_sinh else None,
        "annual_stars": _names(annual_stars),
        "annual_star_details": _details(annual_stars),
        "annual_good_star_details": _details(annual_good + annual_neutral),
        "annual_bad_star_details": _details(annual_bad),
        "tuan": palace["has_tuan"],
        "triet": palace["has_triet"],
    }
