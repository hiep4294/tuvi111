# -*- coding: utf-8 -*-
"""Bridge API for the browser/Pyodide version."""
from __future__ import annotations

import json
from typing import Any, Dict

from tuvi_engine.chart import generate_chart
from tuvi_engine.models import BirthInput
from tuvi_engine.prompts import (
    build_all_relations_prompt,
    build_combined_topic_prompt,
    build_full_report_prompt,
    build_relation_prompt,
)

_current_chart = None


def _result(ok: bool, **payload: Any) -> str:
    return json.dumps({"ok": ok, **payload}, ensure_ascii=False, separators=(",", ":"))


def generate_chart_json(payload_json: str) -> str:
    global _current_chart
    try:
        payload: Dict[str, Any] = json.loads(payload_json)
        birth = BirthInput(
            name=str(payload.get("name", "")).strip(),
            gender=int(payload["gender"]),
            calendar_type="solar",
            day=int(payload["day"]),
            month=int(payload["month"]),
            year=int(payload["year"]),
            hour=int(payload["hour"]),
            minute=int(payload["minute"]),
            is_leap_month=False,
            bazi_month_method="jieqi",
            tu_hoa_method=str(payload.get("tu_hoa_method", "nam_phai_viet")),
            placement_profile="tracuutuvi_reference",
            annual_year=int(payload.get("annual_year", payload["year"])),
        )
        _current_chart = generate_chart(birth)
        return _result(True, chart=_current_chart.to_dict())
    except Exception as exc:
        return _result(False, error=f"{type(exc).__name__}: {exc}")


def build_prompt_json(kind: str, index: int = 0) -> str:
    try:
        if _current_chart is None:
            raise RuntimeError("Chưa lập lá số")
        if kind == "relation":
            text = build_relation_prompt(_current_chart, int(index))
        elif kind == "relations_all":
            text = build_all_relations_prompt(_current_chart)
        elif kind == "combined":
            text = build_combined_topic_prompt(_current_chart, int(index))
        elif kind == "full":
            text = build_full_report_prompt(_current_chart)
        else:
            raise ValueError("Loại prompt không hợp lệ")
        return _result(True, prompt=text)
    except Exception as exc:
        return _result(False, error=f"{type(exc).__name__}: {exc}")


def health_json() -> str:
    return _result(True, engine="TuViBatTuWeb", source="web-v1.11")
